﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class LogIn : Form
    {
        private readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Olivier\Downloads\HealthyEatsProject\HealthyEatsProject-20231205T082621Z-001_2\HealthyEatsProject-20231205T082621Z-001\HealthyEatsProject\HealthyEatsProject\UserDatabase.mdf;Integrated Security=True;Connect Timeout=30";
        public LogIn()
        {
            InitializeComponent();
        }

        private void showCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            passwordTextBox.UseSystemPasswordChar = showCheckBox.Checked;

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            string enteredUsername = usernameTextBox.Text;
            string enteredPassword = passwordTextBox.Text;

            if (IsValidLogin(enteredUsername, enteredPassword))
            {
                MessageBox.Show($"Welcome, {enteredUsername}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MainDashBoardForm mainDashboard = new MainDashBoardForm();
                mainDashboard.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsValidLogin(string username, string password)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(1) FROM [User] WHERE UserName = @username AND Password = @password", conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    int userCount = (int)cmd.ExecuteScalar();
                    return userCount > 0;
                }
            }
        }

        private void SignUpLabel_Click(object sender, EventArgs e)
        {
            SignUp signUpForm = new SignUp();
            signUpForm.Show();
            this.Hide();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
