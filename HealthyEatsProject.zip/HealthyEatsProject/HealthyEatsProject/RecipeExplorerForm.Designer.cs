﻿namespace HealthyEatsProject
{
    partial class RecipeExplorerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label recipeIdLabel;
            System.Windows.Forms.Label recipeNameLabel;
            System.Windows.Forms.Label preparationTimeInMinutesLabel;
            System.Windows.Forms.Label ingredientsLabel;
            System.Windows.Forms.Label instructionsLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RecipeExplorerForm));
            this.recipeLabel = new System.Windows.Forms.Label();
            this.outputRichTextBox = new System.Windows.Forms.RichTextBox();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.searchLabel = new System.Windows.Forms.Label();
            this.recipeIdTextBox = new System.Windows.Forms.TextBox();
            this.recipesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.personalizedMealPlanningDataSet = new HealthyEatsProject.PersonalizedMealPlanningDataSet();
            this.recipeNameTextBox = new System.Windows.Forms.TextBox();
            this.preparationTimeInMinutesTextBox = new System.Windows.Forms.TextBox();
            this.ingredientsTextBox = new System.Windows.Forms.TextBox();
            this.instructionsTextBox = new System.Windows.Forms.TextBox();
            this.recipesTableAdapter = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.RecipesTableAdapter();
            this.tableAdapterManager = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager();
            this.recipesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.recipesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.dateUserControl1 = new HealthyEatsProject.DateUserControl();
            this.timeUserControl1 = new HealthyEatsProject.TimeUserControl();
            recipeIdLabel = new System.Windows.Forms.Label();
            recipeNameLabel = new System.Windows.Forms.Label();
            preparationTimeInMinutesLabel = new System.Windows.Forms.Label();
            ingredientsLabel = new System.Windows.Forms.Label();
            instructionsLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recipesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalizedMealPlanningDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recipesBindingNavigator)).BeginInit();
            this.recipesBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // recipeIdLabel
            // 
            recipeIdLabel.AutoSize = true;
            recipeIdLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            recipeIdLabel.Location = new System.Drawing.Point(26, 52);
            recipeIdLabel.Name = "recipeIdLabel";
            recipeIdLabel.Size = new System.Drawing.Size(83, 21);
            recipeIdLabel.TabIndex = 0;
            recipeIdLabel.Text = "Recipe Id:";
            // 
            // recipeNameLabel
            // 
            recipeNameLabel.AutoSize = true;
            recipeNameLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            recipeNameLabel.Location = new System.Drawing.Point(26, 101);
            recipeNameLabel.Name = "recipeNameLabel";
            recipeNameLabel.Size = new System.Drawing.Size(111, 21);
            recipeNameLabel.TabIndex = 2;
            recipeNameLabel.Text = "Recipe Name:";
            // 
            // preparationTimeInMinutesLabel
            // 
            preparationTimeInMinutesLabel.AutoSize = true;
            preparationTimeInMinutesLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            preparationTimeInMinutesLabel.Location = new System.Drawing.Point(26, 144);
            preparationTimeInMinutesLabel.Name = "preparationTimeInMinutesLabel";
            preparationTimeInMinutesLabel.Size = new System.Drawing.Size(220, 21);
            preparationTimeInMinutesLabel.TabIndex = 4;
            preparationTimeInMinutesLabel.Text = "Preparation Time In Minutes:";
            // 
            // ingredientsLabel
            // 
            ingredientsLabel.AutoSize = true;
            ingredientsLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ingredientsLabel.Location = new System.Drawing.Point(26, 188);
            ingredientsLabel.Name = "ingredientsLabel";
            ingredientsLabel.Size = new System.Drawing.Size(98, 21);
            ingredientsLabel.TabIndex = 6;
            ingredientsLabel.Text = "Ingredients:";
            // 
            // instructionsLabel
            // 
            instructionsLabel.AutoSize = true;
            instructionsLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            instructionsLabel.Location = new System.Drawing.Point(26, 306);
            instructionsLabel.Name = "instructionsLabel";
            instructionsLabel.Size = new System.Drawing.Size(100, 21);
            instructionsLabel.TabIndex = 8;
            instructionsLabel.Text = "Instructions:";
            // 
            // recipeLabel
            // 
            this.recipeLabel.BackColor = System.Drawing.Color.Honeydew;
            this.recipeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.recipeLabel.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recipeLabel.ForeColor = System.Drawing.Color.ForestGreen;
            this.recipeLabel.Location = new System.Drawing.Point(332, 33);
            this.recipeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.recipeLabel.Name = "recipeLabel";
            this.recipeLabel.Size = new System.Drawing.Size(290, 48);
            this.recipeLabel.TabIndex = 0;
            this.recipeLabel.Text = "Recipe Explorer";
            this.recipeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputRichTextBox
            // 
            this.outputRichTextBox.BackColor = System.Drawing.Color.MintCream;
            this.outputRichTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputRichTextBox.Location = new System.Drawing.Point(455, 136);
            this.outputRichTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.outputRichTextBox.Name = "outputRichTextBox";
            this.outputRichTextBox.Size = new System.Drawing.Size(394, 199);
            this.outputRichTextBox.TabIndex = 1;
            this.outputRichTextBox.Text = "";
            // 
            // inputTextBox
            // 
            this.inputTextBox.BackColor = System.Drawing.Color.MintCream;
            this.inputTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputTextBox.Location = new System.Drawing.Point(455, 52);
            this.inputTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(394, 29);
            this.inputTextBox.TabIndex = 2;
            // 
            // detailsButton
            // 
            this.detailsButton.AutoSize = true;
            this.detailsButton.BackColor = System.Drawing.Color.DarkOrange;
            this.detailsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.detailsButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailsButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.detailsButton.Location = new System.Drawing.Point(599, 85);
            this.detailsButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(125, 33);
            this.detailsButton.TabIndex = 3;
            this.detailsButton.Text = "View Details";
            this.detailsButton.UseVisualStyleBackColor = false;
            this.detailsButton.Click += new System.EventHandler(this.ViewDetailsButton_Click);
            // 
            // backButton
            // 
            this.backButton.AutoSize = true;
            this.backButton.BackColor = System.Drawing.Color.DarkOrange;
            this.backButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.backButton.Location = new System.Drawing.Point(599, 351);
            this.backButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(125, 33);
            this.backButton.TabIndex = 4;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.groupBox1.Controls.Add(this.searchLabel);
            this.groupBox1.Controls.Add(recipeIdLabel);
            this.groupBox1.Controls.Add(this.recipeIdTextBox);
            this.groupBox1.Controls.Add(this.backButton);
            this.groupBox1.Controls.Add(recipeNameLabel);
            this.groupBox1.Controls.Add(this.inputTextBox);
            this.groupBox1.Controls.Add(this.detailsButton);
            this.groupBox1.Controls.Add(this.outputRichTextBox);
            this.groupBox1.Controls.Add(this.recipeNameTextBox);
            this.groupBox1.Controls.Add(preparationTimeInMinutesLabel);
            this.groupBox1.Controls.Add(this.preparationTimeInMinutesTextBox);
            this.groupBox1.Controls.Add(ingredientsLabel);
            this.groupBox1.Controls.Add(this.ingredientsTextBox);
            this.groupBox1.Controls.Add(instructionsLabel);
            this.groupBox1.Controls.Add(this.instructionsTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(863, 505);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Recipe Viewer";
            // 
            // searchLabel
            // 
            this.searchLabel.AutoSize = true;
            this.searchLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLabel.Location = new System.Drawing.Point(451, 29);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(63, 21);
            this.searchLabel.TabIndex = 10;
            this.searchLabel.Text = "Search:";
            // 
            // recipeIdTextBox
            // 
            this.recipeIdTextBox.BackColor = System.Drawing.Color.MintCream;
            this.recipeIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.recipesBindingSource, "RecipeId", true));
            this.recipeIdTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recipeIdTextBox.Location = new System.Drawing.Point(157, 53);
            this.recipeIdTextBox.Name = "recipeIdTextBox";
            this.recipeIdTextBox.Size = new System.Drawing.Size(270, 29);
            this.recipeIdTextBox.TabIndex = 1;
            // 
            // recipesBindingSource
            // 
            this.recipesBindingSource.DataMember = "Recipes";
            this.recipesBindingSource.DataSource = this.personalizedMealPlanningDataSet;
            // 
            // personalizedMealPlanningDataSet
            // 
            this.personalizedMealPlanningDataSet.DataSetName = "PersonalizedMealPlanningDataSet";
            this.personalizedMealPlanningDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // recipeNameTextBox
            // 
            this.recipeNameTextBox.BackColor = System.Drawing.Color.MintCream;
            this.recipeNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.recipesBindingSource, "RecipeName", true));
            this.recipeNameTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recipeNameTextBox.Location = new System.Drawing.Point(174, 93);
            this.recipeNameTextBox.Name = "recipeNameTextBox";
            this.recipeNameTextBox.Size = new System.Drawing.Size(253, 29);
            this.recipeNameTextBox.TabIndex = 3;
            // 
            // preparationTimeInMinutesTextBox
            // 
            this.preparationTimeInMinutesTextBox.BackColor = System.Drawing.Color.MintCream;
            this.preparationTimeInMinutesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.recipesBindingSource, "PreparationTimeInMinutes", true));
            this.preparationTimeInMinutesTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preparationTimeInMinutesTextBox.Location = new System.Drawing.Point(304, 136);
            this.preparationTimeInMinutesTextBox.Name = "preparationTimeInMinutesTextBox";
            this.preparationTimeInMinutesTextBox.Size = new System.Drawing.Size(123, 29);
            this.preparationTimeInMinutesTextBox.TabIndex = 5;
            // 
            // ingredientsTextBox
            // 
            this.ingredientsTextBox.BackColor = System.Drawing.Color.MintCream;
            this.ingredientsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.recipesBindingSource, "Ingredients", true));
            this.ingredientsTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ingredientsTextBox.Location = new System.Drawing.Point(136, 186);
            this.ingredientsTextBox.Multiline = true;
            this.ingredientsTextBox.Name = "ingredientsTextBox";
            this.ingredientsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ingredientsTextBox.Size = new System.Drawing.Size(291, 109);
            this.ingredientsTextBox.TabIndex = 7;
            // 
            // instructionsTextBox
            // 
            this.instructionsTextBox.BackColor = System.Drawing.Color.MintCream;
            this.instructionsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.recipesBindingSource, "Instructions", true));
            this.instructionsTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionsTextBox.Location = new System.Drawing.Point(136, 306);
            this.instructionsTextBox.Multiline = true;
            this.instructionsTextBox.Name = "instructionsTextBox";
            this.instructionsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.instructionsTextBox.Size = new System.Drawing.Size(291, 193);
            this.instructionsTextBox.TabIndex = 9;
            // 
            // recipesTableAdapter
            // 
            this.recipesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MealItemsTableAdapter = null;
            this.tableAdapterManager.MealPlansTableAdapter = null;
            this.tableAdapterManager.RecipesTableAdapter = this.recipesTableAdapter;
            this.tableAdapterManager.UpdateOrder = HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // recipesBindingNavigator
            // 
            this.recipesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.recipesBindingNavigator.BindingSource = this.recipesBindingSource;
            this.recipesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.recipesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.recipesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.recipesBindingNavigatorSaveItem});
            this.recipesBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.recipesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.recipesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.recipesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.recipesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.recipesBindingNavigator.Name = "recipesBindingNavigator";
            this.recipesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.recipesBindingNavigator.Size = new System.Drawing.Size(887, 25);
            this.recipesBindingNavigator.TabIndex = 7;
            this.recipesBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Enabled = false;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // recipesBindingNavigatorSaveItem
            // 
            this.recipesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.recipesBindingNavigatorSaveItem.Enabled = false;
            this.recipesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("recipesBindingNavigatorSaveItem.Image")));
            this.recipesBindingNavigatorSaveItem.Name = "recipesBindingNavigatorSaveItem";
            this.recipesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.recipesBindingNavigatorSaveItem.Text = "Save Data";
            this.recipesBindingNavigatorSaveItem.Click += new System.EventHandler(this.recipesBindingNavigatorSaveItem_Click);
            // 
            // dateUserControl1
            // 
            this.dateUserControl1.AutoSize = true;
            this.dateUserControl1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateUserControl1.Location = new System.Drawing.Point(0, 33);
            this.dateUserControl1.Margin = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.dateUserControl1.Name = "dateUserControl1";
            this.dateUserControl1.Size = new System.Drawing.Size(288, 48);
            this.dateUserControl1.TabIndex = 10;
            // 
            // timeUserControl1
            // 
            this.timeUserControl1.Location = new System.Drawing.Point(682, 28);
            this.timeUserControl1.Margin = new System.Windows.Forms.Padding(4);
            this.timeUserControl1.Name = "timeUserControl1";
            this.timeUserControl1.Size = new System.Drawing.Size(193, 53);
            this.timeUserControl1.TabIndex = 9;
            // 
            // RecipeExplorerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(887, 609);
            this.Controls.Add(this.dateUserControl1);
            this.Controls.Add(this.timeUserControl1);
            this.Controls.Add(this.recipesBindingNavigator);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.recipeLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "RecipeExplorerForm";
            this.Text = "Recipe Explorer";
            this.Load += new System.EventHandler(this.RecipeExplorerForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recipesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalizedMealPlanningDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recipesBindingNavigator)).EndInit();
            this.recipesBindingNavigator.ResumeLayout(false);
            this.recipesBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label recipeLabel;
        private System.Windows.Forms.RichTextBox outputRichTextBox;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private PersonalizedMealPlanningDataSet personalizedMealPlanningDataSet;
        private System.Windows.Forms.BindingSource recipesBindingSource;
        private PersonalizedMealPlanningDataSetTableAdapters.RecipesTableAdapter recipesTableAdapter;
        private PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator recipesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton recipesBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox recipeIdTextBox;
        private System.Windows.Forms.TextBox recipeNameTextBox;
        private System.Windows.Forms.TextBox preparationTimeInMinutesTextBox;
        private System.Windows.Forms.TextBox ingredientsTextBox;
        private System.Windows.Forms.TextBox instructionsTextBox;
        private System.Windows.Forms.Label searchLabel;
        private TimeUserControl timeUserControl1;
        private DateUserControl dateUserControl1;
    }
}