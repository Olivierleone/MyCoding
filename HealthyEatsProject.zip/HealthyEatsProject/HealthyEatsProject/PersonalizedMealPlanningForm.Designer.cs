﻿namespace HealthyEatsProject
{
    partial class PersonalizedMealPlanningForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PersonalizedMealPlanningForm));
            this.titleLabel = new System.Windows.Forms.Label();
            this.logoPictureBox = new System.Windows.Forms.PictureBox();
            this.personalizedMealPlanningDataSet = new HealthyEatsProject.PersonalizedMealPlanningDataSet();
            this.mealItemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mealItemsTableAdapter = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.MealItemsTableAdapter();
            this.tableAdapterManager = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager();
            this.generateMealPlanButton = new System.Windows.Forms.Button();
            this.mealItemsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.healthGoalLabel = new System.Windows.Forms.Label();
            this.Restrictions = new System.Windows.Forms.Label();
            this.allergiesLabel = new System.Windows.Forms.Label();
            this.fKMealPlansBreakfastItemIDBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mealPlansTableAdapter = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.MealPlansTableAdapter();
            this.eggTextBox = new System.Windows.Forms.CheckBox();
            this.shellFishTextBox = new System.Windows.Forms.CheckBox();
            this.peanutsCheckBox = new System.Windows.Forms.CheckBox();
            this.glutenFreeCheckBox = new System.Windows.Forms.CheckBox();
            this.veganCheckBox = new System.Windows.Forms.CheckBox();
            this.vegetarianCheckBox = new System.Windows.Forms.CheckBox();
            this.resultTextBox = new System.Windows.Forms.TextBox();
            this.mealsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timeUserControl1 = new HealthyEatsProject.TimeUserControl();
            this.dateUserControl1 = new HealthyEatsProject.DateUserControl();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalizedMealPlanningDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealItemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealItemsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKMealPlansBreakfastItemIDBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealsNumericUpDown)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.BackColor = System.Drawing.Color.Honeydew;
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.titleLabel.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.ForeColor = System.Drawing.Color.Green;
            this.titleLabel.Location = new System.Drawing.Point(622, 95);
            this.titleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(574, 117);
            this.titleLabel.TabIndex = 2;
            this.titleLabel.Text = "Personalized Meal Planning";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // logoPictureBox
            // 
            this.logoPictureBox.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.logoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("logoPictureBox.Image")));
            this.logoPictureBox.Location = new System.Drawing.Point(54, 195);
            this.logoPictureBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.logoPictureBox.Name = "logoPictureBox";
            this.logoPictureBox.Size = new System.Drawing.Size(212, 251);
            this.logoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPictureBox.TabIndex = 4;
            this.logoPictureBox.TabStop = false;
            // 
            // personalizedMealPlanningDataSet
            // 
            this.personalizedMealPlanningDataSet.DataSetName = "PersonalizedMealPlanningDataSet";
            this.personalizedMealPlanningDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mealItemsBindingSource
            // 
            this.mealItemsBindingSource.DataMember = "MealItems";
            this.mealItemsBindingSource.DataSource = this.personalizedMealPlanningDataSet;
            // 
            // mealItemsTableAdapter
            // 
            this.mealItemsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MealItemsTableAdapter = this.mealItemsTableAdapter;
            this.tableAdapterManager.MealPlansTableAdapter = null;
            this.tableAdapterManager.RecipesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // generateMealPlanButton
            // 
            this.generateMealPlanButton.BackColor = System.Drawing.Color.DarkOrange;
            this.generateMealPlanButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateMealPlanButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.generateMealPlanButton.Location = new System.Drawing.Point(755, 874);
            this.generateMealPlanButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.generateMealPlanButton.Name = "generateMealPlanButton";
            this.generateMealPlanButton.Size = new System.Drawing.Size(338, 52);
            this.generateMealPlanButton.TabIndex = 6;
            this.generateMealPlanButton.Text = "Generate Meal Plan";
            this.generateMealPlanButton.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.generateMealPlanButton.UseVisualStyleBackColor = false;
            this.generateMealPlanButton.Click += new System.EventHandler(this.generateMealPlanButton_Click);
            // 
            // mealItemsBindingSource1
            // 
            this.mealItemsBindingSource1.DataMember = "MealItems";
            this.mealItemsBindingSource1.DataSource = this.personalizedMealPlanningDataSet;
            // 
            // healthGoalLabel
            // 
            this.healthGoalLabel.AutoSize = true;
            this.healthGoalLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.healthGoalLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.healthGoalLabel.Location = new System.Drawing.Point(542, 248);
            this.healthGoalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.healthGoalLabel.Name = "healthGoalLabel";
            this.healthGoalLabel.Size = new System.Drawing.Size(83, 32);
            this.healthGoalLabel.TabIndex = 9;
            this.healthGoalLabel.Text = "Name:";
            // 
            // Restrictions
            // 
            this.Restrictions.AutoSize = true;
            this.Restrictions.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Restrictions.Location = new System.Drawing.Point(39, 89);
            this.Restrictions.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Restrictions.Name = "Restrictions";
            this.Restrictions.Size = new System.Drawing.Size(195, 32);
            this.Restrictions.TabIndex = 10;
            this.Restrictions.Text = "Meal Restrictions";
            // 
            // allergiesLabel
            // 
            this.allergiesLabel.AutoSize = true;
            this.allergiesLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allergiesLabel.Location = new System.Drawing.Point(69, 137);
            this.allergiesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.allergiesLabel.Name = "allergiesLabel";
            this.allergiesLabel.Size = new System.Drawing.Size(105, 32);
            this.allergiesLabel.TabIndex = 11;
            this.allergiesLabel.Text = "Allergies";
            // 
            // fKMealPlansBreakfastItemIDBindingSource
            // 
            this.fKMealPlansBreakfastItemIDBindingSource.DataMember = "FK_MealPlans_BreakfastItemID";
            this.fKMealPlansBreakfastItemIDBindingSource.DataSource = this.mealItemsBindingSource;
            // 
            // mealPlansTableAdapter
            // 
            this.mealPlansTableAdapter.ClearBeforeFill = true;
            // 
            // eggTextBox
            // 
            this.eggTextBox.AutoSize = true;
            this.eggTextBox.Location = new System.Drawing.Point(399, 137);
            this.eggTextBox.Name = "eggTextBox";
            this.eggTextBox.Size = new System.Drawing.Size(80, 36);
            this.eggTextBox.TabIndex = 36;
            this.eggTextBox.Text = "Egg";
            this.eggTextBox.UseVisualStyleBackColor = true;
            // 
            // shellFishTextBox
            // 
            this.shellFishTextBox.AutoSize = true;
            this.shellFishTextBox.Location = new System.Drawing.Point(513, 137);
            this.shellFishTextBox.Name = "shellFishTextBox";
            this.shellFishTextBox.Size = new System.Drawing.Size(134, 36);
            this.shellFishTextBox.TabIndex = 35;
            this.shellFishTextBox.Text = "ShellFish";
            this.shellFishTextBox.UseVisualStyleBackColor = true;
            // 
            // peanutsCheckBox
            // 
            this.peanutsCheckBox.AutoSize = true;
            this.peanutsCheckBox.Location = new System.Drawing.Point(240, 137);
            this.peanutsCheckBox.Name = "peanutsCheckBox";
            this.peanutsCheckBox.Size = new System.Drawing.Size(123, 36);
            this.peanutsCheckBox.TabIndex = 34;
            this.peanutsCheckBox.Text = "Peanuts";
            this.peanutsCheckBox.UseVisualStyleBackColor = true;
            // 
            // glutenFreeCheckBox
            // 
            this.glutenFreeCheckBox.AutoSize = true;
            this.glutenFreeCheckBox.Location = new System.Drawing.Point(513, 89);
            this.glutenFreeCheckBox.Name = "glutenFreeCheckBox";
            this.glutenFreeCheckBox.Size = new System.Drawing.Size(164, 36);
            this.glutenFreeCheckBox.TabIndex = 31;
            this.glutenFreeCheckBox.Text = "Gluten Free";
            this.glutenFreeCheckBox.UseVisualStyleBackColor = true;
            // 
            // veganCheckBox
            // 
            this.veganCheckBox.AutoSize = true;
            this.veganCheckBox.Location = new System.Drawing.Point(399, 88);
            this.veganCheckBox.Name = "veganCheckBox";
            this.veganCheckBox.Size = new System.Drawing.Size(106, 36);
            this.veganCheckBox.TabIndex = 30;
            this.veganCheckBox.Text = "Vegan";
            this.veganCheckBox.UseVisualStyleBackColor = true;
            // 
            // vegetarianCheckBox
            // 
            this.vegetarianCheckBox.AutoSize = true;
            this.vegetarianCheckBox.Location = new System.Drawing.Point(240, 89);
            this.vegetarianCheckBox.Name = "vegetarianCheckBox";
            this.vegetarianCheckBox.Size = new System.Drawing.Size(153, 36);
            this.vegetarianCheckBox.TabIndex = 29;
            this.vegetarianCheckBox.Text = "Vegetarian";
            this.vegetarianCheckBox.UseVisualStyleBackColor = true;
            // 
            // resultTextBox
            // 
            this.resultTextBox.BackColor = System.Drawing.Color.Honeydew;
            this.resultTextBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.resultTextBox.Location = new System.Drawing.Point(404, 509);
            this.resultTextBox.Multiline = true;
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.resultTextBox.Size = new System.Drawing.Size(973, 357);
            this.resultTextBox.TabIndex = 28;
            // 
            // mealsNumericUpDown
            // 
            this.mealsNumericUpDown.BackColor = System.Drawing.Color.Honeydew;
            this.mealsNumericUpDown.Location = new System.Drawing.Point(248, 32);
            this.mealsNumericUpDown.Name = "mealsNumericUpDown";
            this.mealsNumericUpDown.Size = new System.Drawing.Size(120, 39);
            this.mealsNumericUpDown.TabIndex = 26;
            // 
            // nameTextBox
            // 
            this.nameTextBox.BackColor = System.Drawing.Color.Honeydew;
            this.nameTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nameTextBox.Location = new System.Drawing.Point(664, 243);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(493, 39);
            this.nameTextBox.TabIndex = 25;
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberLabel.Location = new System.Drawing.Point(39, 40);
            this.numberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(205, 32);
            this.numberLabel.TabIndex = 38;
            this.numberLabel.Text = "Number of meals:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkOrange;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(36, 602);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(249, 85);
            this.button1.TabIndex = 39;
            this.button1.Text = "Nutritional Information";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.nutritionalInfoButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.DarkOrange;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(36, 748);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(249, 52);
            this.exitButton.TabIndex = 40;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // backButton
            // 
            this.backButton.BackColor = System.Drawing.Color.DarkOrange;
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(36, 806);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(249, 46);
            this.backButton.TabIndex = 41;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mealsNumericUpDown);
            this.groupBox1.Controls.Add(this.numberLabel);
            this.groupBox1.Controls.Add(this.allergiesLabel);
            this.groupBox1.Controls.Add(this.peanutsCheckBox);
            this.groupBox1.Controls.Add(this.glutenFreeCheckBox);
            this.groupBox1.Controls.Add(this.eggTextBox);
            this.groupBox1.Controls.Add(this.veganCheckBox);
            this.groupBox1.Controls.Add(this.shellFishTextBox);
            this.groupBox1.Controls.Add(this.vegetarianCheckBox);
            this.groupBox1.Controls.Add(this.Restrictions);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(548, 318);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(682, 183);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Preferences";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.backButton);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.exitButton);
            this.panel1.Controls.Add(this.logoPictureBox);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 997);
            this.panel1.TabIndex = 43;
            // 
            // timeUserControl1
            // 
            this.timeUserControl1.Location = new System.Drawing.Point(1119, 0);
            this.timeUserControl1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.timeUserControl1.Name = "timeUserControl1";
            this.timeUserControl1.Size = new System.Drawing.Size(292, 74);
            this.timeUserControl1.TabIndex = 45;
            // 
            // dateUserControl1
            // 
            this.dateUserControl1.AutoSize = true;
            this.dateUserControl1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateUserControl1.Location = new System.Drawing.Point(345, 0);
            this.dateUserControl1.Margin = new System.Windows.Forms.Padding(15, 12, 15, 12);
            this.dateUserControl1.Name = "dateUserControl1";
            this.dateUserControl1.Size = new System.Drawing.Size(574, 83);
            this.dateUserControl1.TabIndex = 44;
            // 
            // PersonalizedMealPlanningForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(1426, 940);
            this.Controls.Add(this.timeUserControl1);
            this.Controls.Add(this.dateUserControl1);
            this.Controls.Add(this.resultTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.healthGoalLabel);
            this.Controls.Add(this.generateMealPlanButton);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ForeColor = System.Drawing.Color.ForestGreen;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "PersonalizedMealPlanningForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Personalized Meal Planning Form";
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalizedMealPlanningDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealItemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealItemsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKMealPlansBreakfastItemIDBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealsNumericUpDown)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.PictureBox logoPictureBox;
        private PersonalizedMealPlanningDataSet personalizedMealPlanningDataSet;
        private System.Windows.Forms.BindingSource mealItemsBindingSource;
        private PersonalizedMealPlanningDataSetTableAdapters.MealItemsTableAdapter mealItemsTableAdapter;
        private PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label healthGoalLabel;
        private System.Windows.Forms.Label Restrictions;
        private System.Windows.Forms.Label allergiesLabel;
        private System.Windows.Forms.BindingSource mealItemsBindingSource1;
        private System.Windows.Forms.BindingSource fKMealPlansBreakfastItemIDBindingSource;
        private PersonalizedMealPlanningDataSetTableAdapters.MealPlansTableAdapter mealPlansTableAdapter;
        private System.Windows.Forms.CheckBox eggTextBox;
        private System.Windows.Forms.CheckBox shellFishTextBox;
        private System.Windows.Forms.CheckBox peanutsCheckBox;
        private System.Windows.Forms.CheckBox glutenFreeCheckBox;
        private System.Windows.Forms.CheckBox veganCheckBox;
        private System.Windows.Forms.CheckBox vegetarianCheckBox;
        private System.Windows.Forms.TextBox resultTextBox;
        private System.Windows.Forms.Button generateMealPlanButton;
        private System.Windows.Forms.NumericUpDown mealsNumericUpDown;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Button generateMealPlanButton1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private DateUserControl dateUserControl1;
        private TimeUserControl timeUserControl1;
    }
}