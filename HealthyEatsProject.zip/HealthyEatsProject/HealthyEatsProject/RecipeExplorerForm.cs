﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class RecipeExplorerForm : Form
    {

        private MainDashBoardForm mainDashboardForm;
        public RecipeExplorerForm(MainDashBoardForm mainDashboardForm)
        {
            InitializeComponent();
            this.mainDashboardForm = mainDashboardForm;
        }

        private void ViewDetailsButton_Click(object sender, EventArgs e)
        {
            // Retrieve the user input from the textbox
            string userRequestedRecipe = inputTextBox.Text;

            // Call a method to fetch the full recipe details based on the user input
            string fullRecipeDetails = FetchRecipeDetails(userRequestedRecipe);

            // Display the full recipe details in the rich text box
            outputRichTextBox.Text = fullRecipeDetails;
        }

        private string FetchRecipeDetails(string recipeName)
        {
            // Simulate fetching recipe details from your data source
            // Replace this with actual logic to retrieve recipe details

            // For demonstration purposes, let's return mock recipes for two options
            if (recipeName.Equals("Pasta Carbonara", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Pasta Carbonara\n\nIngredients:\n- Spaghetti\n- Eggs\n- Pancetta\n- Parmesan cheese\n- Salt\n- Black pepper\n\nInstructions:\n1. Cook the pasta according to package instructions.\n2. In a bowl, whisk together eggs, grated Parmesan cheese, and black pepper.\n3. In a pan, sauté pancetta until crispy.\n4. Toss cooked pasta with the egg mixture and pancetta. Serve with additional Parmesan and black pepper.";
            }
            else if (recipeName.Equals("Grilled Chicken Salad", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Grilled Chicken Salad\n\nIngredients:\n- Chicken breast\n- Mixed greens\n- Cherry tomatoes\n- Cucumber\n- Red onion\n- Feta cheese\n- Olive oil\n- Balsamic vinegar\n- Salt\n- Pepper\n\nInstructions:\n1. Season chicken breast with salt and pepper, then grill until cooked.\n2. Chop grilled chicken into bite-sized pieces.\n3. In a large bowl, combine mixed greens, cherry tomatoes, sliced cucumber, diced red onion, and feta cheese.\n4. Top the salad with grilled chicken.\n5. Drizzle with olive oil and balsamic vinegar. Toss to combine.";
            }
            else if (recipeName.Equals("Spaghetti Bolognese", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Spaghetti Bolognese\n\nIngredients:\n- Ground beef\n- Onion\n- Garlic\n- Tomato sauce\n- Tomato paste\n- Italian seasoning\n- Salt\n- Black pepper\n- Spaghetti\n\nInstructions:\n1. In a pan, sauté chopped onions and garlic until golden.\n2. Add ground beef and cook until browned.\n3. Stir in tomato sauce, tomato paste, Italian seasoning, salt, and black pepper.\n4. Simmer for 20 minutes. Serve over cooked spaghetti.";
            }
            else if (recipeName.Equals("Chicken Alfredo", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Chicken Alfredo\n\nIngredients:\n- Fettuccine pasta\n- Chicken breast\n- Heavy cream\n- Parmesan cheese\n- Garlic\n- Butter\n- Salt\n- Black pepper\n\nInstructions:\n1. Cook fettuccine pasta according to package instructions.\n2. Season chicken breast with salt and pepper, then cook until fully cooked.\n3. In a saucepan, melt butter and sauté minced garlic.\n4. Pour in heavy cream and Parmesan cheese. Stir until the cheese is melted.\n5. Slice cooked chicken and add it to the sauce. Serve over fettuccine pasta.";
            }
            else if (recipeName.Equals("Vegetarian Stir-Fry", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Vegetarian Stir-Fry\n\nIngredients:\n- Tofu\n- Broccoli\n- Bell peppers\n- Carrots\n- Snap peas\n- Soy sauce\n- Sesame oil\n- Ginger\n- Garlic\n- Rice\n\nInstructions:\n1. Press tofu to remove excess water, then cut into cubes.\n2. Stir-fry tofu in sesame oil until golden.\n3. Add chopped vegetables, ginger, and garlic. Stir-fry until vegetables are tender.\n4. Pour soy sauce over the stir-fry and toss to combine.\n5. Serve over cooked rice.";
            }
            else if (recipeName.Equals("Salmon with Lemon-Dill Sauce", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Salmon with Lemon-Dill Sauce\n\nIngredients:\n- Salmon fillets\n- Lemon\n- Fresh dill\n- Olive oil\n- Salt\n- Black pepper\n- Garlic\n\nInstructions:\n1. Preheat oven to 375°F (190°C).\n2. Season salmon fillets with salt, pepper, and minced garlic.\n3. Place salmon on a baking sheet and drizzle with olive oil.\n4. Bake for 15-20 minutes or until salmon is cooked through.\n5. Prepare a sauce with chopped dill and lemon juice. Drizzle over the salmon before serving.";
            }
            else if (recipeName.Equals("Caprese Salad", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Caprese Salad\n\nIngredients:\n- Tomatoes\n- Fresh mozzarella\n- Basil leaves\n- Balsamic glaze\n- Olive oil\n- Salt\n- Black pepper\n\nInstructions:\n1. Slice tomatoes and fresh mozzarella into even slices.\n2. Arrange tomato and mozzarella slices on a serving plate, alternating with fresh basil leaves.\n3. Drizzle with balsamic glaze and olive oil.\n4. Sprinkle with salt and black pepper. Serve immediately.";
            }
            else if (recipeName.Equals("Shrimp Scampi", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Shrimp Scampi\n\nIngredients:\n- Shrimp\n- Linguine pasta\n- Butter\n- Olive oil\n- Garlic\n- White wine\n- Lemon juice\n- Red pepper flakes\n- Parsley\n- Salt\n- Black pepper\n\nInstructions:\n1. Cook linguine pasta according to package instructions.\n2. In a pan, sauté shrimp in butter and olive oil until pink.\n3. Add minced garlic, white wine, lemon juice, and red pepper flakes. Simmer until flavors combine.\n4. Toss cooked pasta with the shrimp mixture. Garnish with chopped parsley.";
            }
            else if (recipeName.Equals("Quinoa Salad", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Quinoa Salad\n\nIngredients:\n- Quinoa\n- Cucumber\n- Cherry tomatoes\n- Red onion\n- Feta cheese\n- Kalamata olives\n- Olive oil\n- Lemon juice\n- Oregano\n- Salt\n- Black pepper\n\nInstructions:\n1. Cook quinoa according to package instructions.\n2. In a large bowl, combine quinoa, diced cucumber, halved cherry tomatoes, sliced red onion, feta cheese, and Kalamata olives.\n3. Drizzle with olive oil and lemon juice. Sprinkle with oregano, salt, and black pepper. Toss to combine.";
            }
            else if (recipeName.Equals("Teriyaki Chicken", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Teriyaki Chicken\n\nIngredients:\n- Chicken thighs\n- Soy sauce\n- Brown sugar\n- Honey\n- Garlic\n- Ginger\n- Sesame oil\n- Cornstarch\n- Green onions\n- Sesame seeds\n\nInstructions:\n1. Combine soy sauce, brown sugar, honey, minced garlic, minced ginger, and sesame oil to make the teriyaki sauce.\n2. Marinate chicken thighs in the teriyaki sauce for at least 30 minutes.\n3. Grill or bake chicken until fully cooked.\n4. In a saucepan, heat the remaining teriyaki sauce with cornstarch until thickened.\n5. Drizzle the sauce over cooked chicken. Garnish with chopped green onions and sesame seeds.";
            }
            else if (recipeName.Equals("Mushroom Risotto", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Mushroom Risotto\n\nIngredients:\n- Arborio rice\n- Mushrooms\n- Onion\n- Garlic\n- White wine\n- Vegetable broth\n- Parmesan cheese\n- Butter\n- Olive oil\n- Thyme\n- Salt\n- Black pepper\n\nInstructions:\n1. Sauté chopped onions and garlic in butter and olive oil until softened.\n2. Add sliced mushrooms and cook until browned.\n3. Stir in Arborio rice and cook until lightly toasted.\n4. Pour in white wine and cook until evaporated.\n5. Gradually add warm vegetable broth, stirring constantly until rice is cooked.\n6. Stir in Parmesan cheese, thyme, salt, and black pepper. Serve hot.";
            }
            else if (recipeName.Equals("Eggplant Parmesan", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Eggplant Parmesan\n\nIngredients:\n- Eggplant\n- Marinara sauce\n- Mozzarella cheese\n- Parmesan cheese\n- Bread crumbs\n- Eggs\n- Fresh basil\n- Olive oil\n- Salt\n- Black pepper\n\nInstructions:\n1. Slice eggplant into rounds, dip in beaten eggs, and coat with bread crumbs.\n2. Bake eggplant rounds until golden and crispy.\n3. In a baking dish, layer marinara sauce, eggplant rounds, mozzarella cheese, and Parmesan cheese.\n4. Repeat the layers and bake until cheese is melted and bubbly.\n5. Garnish with fresh basil and season with salt and black pepper.";
            }
            else if (recipeName.Equals("Black Bean Burritos", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Black Bean Burritos\n\nIngredients:\n- Black beans\n- Tortillas\n- Avocado\n- Salsa\n- Sour cream\n- Cilantro\n- Lime\n- Rice\n- Cumin\n- Garlic powder\n- Salt\n- Black pepper\n\nInstructions:\n1. Rinse and drain black beans. Season with cumin, garlic powder, salt, and black pepper.\n2. Warm tortillas and assemble burritos with black beans, rice, sliced avocado, salsa, and sour cream.\n3. Garnish with chopped cilantro and a squeeze of lime.";
            }
            else if (recipeName.Equals("Beef and Broccoli Stir-Fry", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Beef and Broccoli Stir-Fry\n\nIngredients:\n- Beef sirloin\n- Broccoli\n- Soy sauce\n- Ginger\n- Garlic\n- Brown sugar\n- Sesame oil\n- Cornstarch\n- Rice\n- Green onions\n\nInstructions:\n1. Slice beef thinly and marinate in soy sauce, minced ginger, minced garlic, brown sugar, and sesame oil.\n2. Stir-fry beef in a hot pan until browned. Remove from the pan.\n3. Stir-fry broccoli until tender-crisp.\n4. In a small bowl, mix cornstarch with water to make a slurry.\n5. Return beef to the pan, add the slurry, and cook until the sauce thickens.\n6. Serve over cooked rice and garnish with sliced green onions.";
            }
            else if (recipeName.Equals("Lemon Garlic Shrimp Pasta", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Lemon Garlic Shrimp Pasta\n\nIngredients:\n- Shrimp\n- Linguine pasta\n- Lemon\n- Garlic\n- Olive oil\n- Red pepper flakes\n- Parsley\n- Salt\n- Black pepper\n\nInstructions:\n1. Cook linguine pasta according to package instructions.\n2. Sauté shrimp in olive oil with minced garlic until pink.\n3. Add lemon juice, red pepper flakes, salt, and black pepper.\n4. Toss cooked pasta with the shrimp mixture. Garnish with chopped parsley.";
            }
            else if (recipeName.Equals("Chicken Caesar Salad", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Chicken Caesar Salad\n\nIngredients:\n- Romaine lettuce\n- Grilled chicken\n- Croutons\n- Parmesan cheese\n- Caesar dressing\n- Lemon\n- Olive oil\n- Garlic\n- Dijon mustard\n\nInstructions:\n1. Chop romaine lettuce and place it in a bowl.\n2. Top with grilled chicken, croutons, and shaved Parmesan cheese.\n3. In a small bowl, whisk together Caesar dressing, lemon juice, olive oil, and minced garlic.\n4. Drizzle the dressing over the salad and toss to combine.";
            }
            else if (recipeName.Equals("Vegetable Curry", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Vegetable Curry\n\nIngredients:\n- Mixed vegetables (e.g., carrots, peas, potatoes)\n- Curry powder\n- Coconut milk\n- Onion\n- Garlic\n- Ginger\n- Tomatoes\n- Cilantro\n- Basmati rice\n- Cumin\n- Turmeric\n- Coriander\n\nInstructions:\n1. Sauté chopped onions, garlic, and ginger in a pot.\n2. Add curry powder, cumin, turmeric, and coriander. Stir until fragrant.\n3. Add mixed vegetables, coconut milk, and diced tomatoes. Simmer until vegetables are tender.\n4. Serve over cooked basmati rice. Garnish with chopped cilantro.";
            }
            else if (recipeName.Equals("Hawaiian Pizza", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Hawaiian Pizza\n\nIngredients:\n- Pizza dough\n- Pizza sauce\n- Mozzarella cheese\n- Ham\n- Pineapple chunks\n- Red onion\n- Olive oil\n- Red pepper flakes\n\nInstructions:\n1. Preheat oven according to pizza dough instructions.\n2. Roll out the pizza dough and spread pizza sauce over it.\n3. Top with mozzarella cheese, sliced ham, pineapple chunks, and thinly sliced red onion.\n4. Drizzle with olive oil and sprinkle with red pepper flakes.\n5. Bake until the crust is golden and the cheese is bubbly.";
            }
            else if (recipeName.Equals("Avocado Toast", StringComparison.OrdinalIgnoreCase))
            {
                return "Full Recipe Details for Avocado Toast\n\nIngredients:\n- Bread slices\n- Avocado\n- Cherry tomatoes\n- Feta cheese\n- Olive oil\n- Salt\n- Black pepper\n- Red pepper flakes\n\nInstructions:\n1. Toast bread slices until golden.\n2. Mash ripe avocado and spread it over the toasted bread.\n3. Top with halved cherry tomatoes, crumbled feta cheese, and a drizzle of olive oil.\n4. Season with salt, black pepper, and red pepper flakes.";
            }
            // If the recipe is not found
            return "Recipe not found. Please try another recipe.";
        }

        private void backButton_Click(object sender, EventArgs e)
        {

            // Show the main dashboard form and close the recipe explorer form
            mainDashboardForm.Show();
            this.Close();

        }

        private void recipesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.recipesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personalizedMealPlanningDataSet);

        }

        private void RecipeExplorerForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personalizedMealPlanningDataSet.Recipes' table. You can move, or remove it, as needed.
            this.recipesTableAdapter.Fill(this.personalizedMealPlanningDataSet.Recipes);

        }

    }
}



