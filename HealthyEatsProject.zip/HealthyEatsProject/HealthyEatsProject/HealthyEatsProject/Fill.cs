﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class Fill : Form
    {
        public Login login;
        public LoggingIn loggingIn;
        public Fill()
        {
            InitializeComponent();
            this.login = login;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        private void returnFillBtn_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            login.Show();
            login.Visible = true;

        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(firstNameTextBox.Text) || string.IsNullOrWhiteSpace(lastNameTextBox.Text) ||
                (!maleRadioButton.Checked && !femaleRadioButton.Checked) || heightNumericUpDown.Value == 0 ||
                weightNumericUpDown.Value == 0)
            {
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string username = login.Username;
                    string password = login.Password;
                    string fname = firstNameTextBox.Text;
                    string lname = lastNameTextBox.Text;
                    string dobStr = dateOfBirthTimePicker.Value.ToString("yyyy-MM-dd");
                    string email = emailTextBox.Text;
                    string phone = phoneTextBox.Text;
                    string gender = maleRadioButton.Checked ? "M" : "F";
                    decimal height = heightNumericUpDown.Value;
                    decimal weight = weightNumericUpDown.Value;
                     // this.userTableAdapter.InsertNewUser(username, password, fname, lname, dobStr, email, phone, gender, height, weight);
                    //this.userTableAdapter.Fill(this.userDataSet.User);
                    MessageBox.Show("User Registration Completed.", "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);

                 
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"Registration failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        //private void FillInForm_Load(object sender, EventArgs e)
        //{
        //    this.userTableAdapter.Fill(this.userDataSet.User);

        //}



    }
}
