﻿namespace HealthyEatsProject
{
    partial class MainDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.homeLabel = new System.Windows.Forms.Label();
            this.PersonalizedMealPlanningLabel = new System.Windows.Forms.Label();
            this.GroceryLabel = new System.Windows.Forms.Label();
            this.communityForumLabel = new System.Windows.Forms.Label();
            this.logOutButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.bmiGroupBox = new System.Windows.Forms.GroupBox();
            this.heightLabel = new System.Windows.Forms.Label();
            this.weightLabel = new System.Windows.Forms.Label();
            this.numericLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.heightNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.weightNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.settingsLabel = new System.Windows.Forms.Label();
            this.numericTextBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.bmiGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.heightNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weightNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // homeLabel
            // 
            this.homeLabel.AutoSize = true;
            this.homeLabel.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeLabel.Location = new System.Drawing.Point(25, 24);
            this.homeLabel.Name = "homeLabel";
            this.homeLabel.Size = new System.Drawing.Size(80, 33);
            this.homeLabel.TabIndex = 0;
            this.homeLabel.Text = "Home";
            // 
            // PersonalizedMealPlanningLabel
            // 
            this.PersonalizedMealPlanningLabel.AutoSize = true;
            this.PersonalizedMealPlanningLabel.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PersonalizedMealPlanningLabel.Location = new System.Drawing.Point(25, 77);
            this.PersonalizedMealPlanningLabel.Name = "PersonalizedMealPlanningLabel";
            this.PersonalizedMealPlanningLabel.Size = new System.Drawing.Size(322, 33);
            this.PersonalizedMealPlanningLabel.TabIndex = 1;
            this.PersonalizedMealPlanningLabel.Text = "Personalized meal Planning";
            // 
            // GroceryLabel
            // 
            this.GroceryLabel.AutoSize = true;
            this.GroceryLabel.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroceryLabel.Location = new System.Drawing.Point(25, 125);
            this.GroceryLabel.Name = "GroceryLabel";
            this.GroceryLabel.Size = new System.Drawing.Size(269, 33);
            this.GroceryLabel.TabIndex = 2;
            this.GroceryLabel.Text = "Grocery List Generator";
            // 
            // communityForumLabel
            // 
            this.communityForumLabel.AutoSize = true;
            this.communityForumLabel.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.communityForumLabel.Location = new System.Drawing.Point(25, 183);
            this.communityForumLabel.Name = "communityForumLabel";
            this.communityForumLabel.Size = new System.Drawing.Size(225, 33);
            this.communityForumLabel.TabIndex = 3;
            this.communityForumLabel.Text = "Community Forum";
            // 
            // logOutButton
            // 
            this.logOutButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutButton.Location = new System.Drawing.Point(31, 309);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(136, 41);
            this.logOutButton.TabIndex = 5;
            this.logOutButton.Text = "LOG OUT";
            this.logOutButton.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.monthCalendar1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(385, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(339, 298);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Daily Planner";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(10, 35);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(7);
            this.monthCalendar1.MaxSelectionCount = 1;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 18;
            // 
            // bmiGroupBox
            // 
            this.bmiGroupBox.Controls.Add(this.textBox1);
            this.bmiGroupBox.Controls.Add(this.numericTextBox);
            this.bmiGroupBox.Controls.Add(this.weightNumericUpDown);
            this.bmiGroupBox.Controls.Add(this.heightNumericUpDown);
            this.bmiGroupBox.Controls.Add(this.label4);
            this.bmiGroupBox.Controls.Add(this.numericLabel);
            this.bmiGroupBox.Controls.Add(this.weightLabel);
            this.bmiGroupBox.Controls.Add(this.heightLabel);
            this.bmiGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmiGroupBox.Location = new System.Drawing.Point(76, 400);
            this.bmiGroupBox.Name = "bmiGroupBox";
            this.bmiGroupBox.Size = new System.Drawing.Size(648, 182);
            this.bmiGroupBox.TabIndex = 21;
            this.bmiGroupBox.TabStop = false;
            this.bmiGroupBox.Text = "BMI Calculator";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heightLabel.Location = new System.Drawing.Point(6, 43);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(159, 27);
            this.heightLabel.TabIndex = 4;
            this.heightLabel.Text = "Height (inches)";
            // 
            // weightLabel
            // 
            this.weightLabel.AutoSize = true;
            this.weightLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weightLabel.Location = new System.Drawing.Point(6, 96);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(120, 27);
            this.weightLabel.TabIndex = 5;
            this.weightLabel.Text = "Weight (lb)";
            // 
            // numericLabel
            // 
            this.numericLabel.AutoSize = true;
            this.numericLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericLabel.Location = new System.Drawing.Point(331, 17);
            this.numericLabel.Name = "numericLabel";
            this.numericLabel.Size = new System.Drawing.Size(154, 27);
            this.numericLabel.TabIndex = 6;
            this.numericLabel.Text = "Numeric Value";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(331, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 27);
            this.label4.TabIndex = 7;
            this.label4.Text = "Community Forum";
            // 
            // heightNumericUpDown
            // 
            this.heightNumericUpDown.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heightNumericUpDown.Location = new System.Drawing.Point(183, 43);
            this.heightNumericUpDown.Margin = new System.Windows.Forms.Padding(2);
            this.heightNumericUpDown.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.heightNumericUpDown.Name = "heightNumericUpDown";
            this.heightNumericUpDown.Size = new System.Drawing.Size(71, 34);
            this.heightNumericUpDown.TabIndex = 20;
            this.heightNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // weightNumericUpDown
            // 
            this.weightNumericUpDown.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weightNumericUpDown.Location = new System.Drawing.Point(183, 96);
            this.weightNumericUpDown.Margin = new System.Windows.Forms.Padding(2);
            this.weightNumericUpDown.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.weightNumericUpDown.Name = "weightNumericUpDown";
            this.weightNumericUpDown.Size = new System.Drawing.Size(71, 34);
            this.weightNumericUpDown.TabIndex = 21;
            this.weightNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // settingsLabel
            // 
            this.settingsLabel.AutoSize = true;
            this.settingsLabel.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsLabel.Location = new System.Drawing.Point(25, 236);
            this.settingsLabel.Name = "settingsLabel";
            this.settingsLabel.Size = new System.Drawing.Size(105, 33);
            this.settingsLabel.TabIndex = 4;
            this.settingsLabel.Text = "Settings";
            // 
            // numericTextBox
            // 
            this.numericTextBox.Location = new System.Drawing.Point(336, 46);
            this.numericTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.numericTextBox.Name = "numericTextBox";
            this.numericTextBox.Size = new System.Drawing.Size(138, 35);
            this.numericTextBox.TabIndex = 26;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(336, 142);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(138, 35);
            this.textBox1.TabIndex = 27;
            // 
            // MainDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 616);
            this.Controls.Add(this.bmiGroupBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.settingsLabel);
            this.Controls.Add(this.communityForumLabel);
            this.Controls.Add(this.GroceryLabel);
            this.Controls.Add(this.PersonalizedMealPlanningLabel);
            this.Controls.Add(this.homeLabel);
            this.Name = "MainDashBoard";
            this.Text = "MainDashBoard";
            this.groupBox1.ResumeLayout(false);
            this.bmiGroupBox.ResumeLayout(false);
            this.bmiGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.heightNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weightNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label homeLabel;
        private System.Windows.Forms.Label PersonalizedMealPlanningLabel;
        private System.Windows.Forms.Label GroceryLabel;
        private System.Windows.Forms.Label communityForumLabel;
        private System.Windows.Forms.Button logOutButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.GroupBox bmiGroupBox;
        private System.Windows.Forms.NumericUpDown weightNumericUpDown;
        private System.Windows.Forms.NumericUpDown heightNumericUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label numericLabel;
        private System.Windows.Forms.Label weightLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox numericTextBox;
        private System.Windows.Forms.Label settingsLabel;
    }
}