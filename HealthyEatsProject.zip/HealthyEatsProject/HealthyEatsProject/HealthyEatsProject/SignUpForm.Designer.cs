﻿namespace HealthyEatsProject
{
    partial class SignUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userNameTextBox = new System.Windows.Forms.TextBox();
            this.userNameSignLabel = new System.Windows.Forms.Label();
            this.passwordSignLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // userNameTextBox
            // 
            this.userNameTextBox.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameTextBox.Location = new System.Drawing.Point(268, 306);
            this.userNameTextBox.Name = "userNameTextBox";
            this.userNameTextBox.Size = new System.Drawing.Size(328, 30);
            this.userNameTextBox.TabIndex = 0;
            // 
            // userNameSignLabel
            // 
            this.userNameSignLabel.AutoSize = true;
            this.userNameSignLabel.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameSignLabel.Location = new System.Drawing.Point(147, 309);
            this.userNameSignLabel.Name = "userNameSignLabel";
            this.userNameSignLabel.Size = new System.Drawing.Size(97, 23);
            this.userNameSignLabel.TabIndex = 1;
            this.userNameSignLabel.Text = "Username";
            this.userNameSignLabel.Click += new System.EventHandler(this.userNameSignLabel_Click);
            // 
            // passwordSignLabel
            // 
            this.passwordSignLabel.AutoSize = true;
            this.passwordSignLabel.Font = new System.Drawing.Font("Bahnschrift", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordSignLabel.Location = new System.Drawing.Point(149, 379);
            this.passwordSignLabel.Name = "passwordSignLabel";
            this.passwordSignLabel.Size = new System.Drawing.Size(95, 23);
            this.passwordSignLabel.TabIndex = 2;
            this.passwordSignLabel.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(268, 372);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(328, 30);
            this.textBox1.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(722, 141);
            this.panel1.TabIndex = 4;
            // 
            // SignUpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 607);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.passwordSignLabel);
            this.Controls.Add(this.userNameSignLabel);
            this.Controls.Add(this.userNameTextBox);
            this.Controls.Add(this.panel1);
            this.Name = "SignUpForm";
            this.Text = "Sign Up";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox userNameTextBox;
        private System.Windows.Forms.Label userNameSignLabel;
        private System.Windows.Forms.Label passwordSignLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1;
    }
}