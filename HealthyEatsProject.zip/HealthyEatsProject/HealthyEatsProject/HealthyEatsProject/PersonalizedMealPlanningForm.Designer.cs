﻿namespace HealthyEatsProject
{
    partial class PersonalizedMealPlanningForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PersonalizedMealPlanningForm));
            this.titleLabel = new System.Windows.Forms.Label();
            this.layoutPictureBox = new System.Windows.Forms.PictureBox();
            this.logoPictureBox = new System.Windows.Forms.PictureBox();
            this.personalizedMealPlanningDataSet = new HealthyEatsProject.PersonalizedMealPlanningDataSet();
            this.mealItemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mealItemsTableAdapter = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.MealItemsTableAdapter();
            this.tableAdapterManager = new HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager();
            this.menuLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.layoutPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalizedMealPlanningDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealItemsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.BackColor = System.Drawing.Color.MintCream;
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.titleLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.ForeColor = System.Drawing.Color.Black;
            this.titleLabel.Location = new System.Drawing.Point(445, 31);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(306, 54);
            this.titleLabel.TabIndex = 2;
            this.titleLabel.Text = "Personalized Meal Planning";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // layoutPictureBox
            // 
            this.layoutPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("layoutPictureBox.Image")));
            this.layoutPictureBox.Location = new System.Drawing.Point(12, -1);
            this.layoutPictureBox.Name = "layoutPictureBox";
            this.layoutPictureBox.Size = new System.Drawing.Size(212, 670);
            this.layoutPictureBox.TabIndex = 3;
            this.layoutPictureBox.TabStop = false;
            // 
            // logoPictureBox
            // 
            this.logoPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.logoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("logoPictureBox.Image")));
            this.logoPictureBox.Location = new System.Drawing.Point(35, 31);
            this.logoPictureBox.Name = "logoPictureBox";
            this.logoPictureBox.Size = new System.Drawing.Size(164, 140);
            this.logoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPictureBox.TabIndex = 4;
            this.logoPictureBox.TabStop = false;
            // 
            // personalizedMealPlanningDataSet
            // 
            this.personalizedMealPlanningDataSet.DataSetName = "PersonalizedMealPlanningDataSet";
            this.personalizedMealPlanningDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mealItemsBindingSource
            // 
            this.mealItemsBindingSource.DataMember = "MealItems";
            this.mealItemsBindingSource.DataSource = this.personalizedMealPlanningDataSet;
            // 
            // mealItemsTableAdapter
            // 
            this.mealItemsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.MealItemsTableAdapter = this.mealItemsTableAdapter;
            this.tableAdapterManager.MealPlansTableAdapter = null;
            this.tableAdapterManager.RecipesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = HealthyEatsProject.PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // menuLabel
            // 
            this.menuLabel.AutoSize = true;
            this.menuLabel.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuLabel.Location = new System.Drawing.Point(69, 192);
            this.menuLabel.Name = "menuLabel";
            this.menuLabel.Size = new System.Drawing.Size(99, 20);
            this.menuLabel.TabIndex = 5;
            this.menuLabel.Text = "Control Menu";
            // 
            // PersonalizedMealPlanningForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(900, 689);
            this.Controls.Add(this.menuLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.logoPictureBox);
            this.Controls.Add(this.layoutPictureBox);
            this.Name = "PersonalizedMealPlanningForm";
            this.Text = "PersonalizedMealPlanningForm";
            this.Load += new System.EventHandler(this.PersonalizedMealPlanningForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.layoutPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personalizedMealPlanningDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mealItemsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.PictureBox layoutPictureBox;
        private System.Windows.Forms.PictureBox logoPictureBox;
        private PersonalizedMealPlanningDataSet personalizedMealPlanningDataSet;
        private System.Windows.Forms.BindingSource mealItemsBindingSource;
        private PersonalizedMealPlanningDataSetTableAdapters.MealItemsTableAdapter mealItemsTableAdapter;
        private PersonalizedMealPlanningDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label menuLabel;
    }
}