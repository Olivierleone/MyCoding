﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class PersonalizedMealPlanningForm : Form
    {
        public PersonalizedMealPlanningForm()
        {
            InitializeComponent();
        }

        private void mealItemsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.mealItemsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personalizedMealPlanningDataSet);

        }

        private void PersonalizedMealPlanningForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personalizedMealPlanningDataSet.MealItems' table. You can move, or remove it, as needed.
            this.mealItemsTableAdapter.Fill(this.personalizedMealPlanningDataSet.MealItems);
            logoPictureBox.Parent = layoutPictureBox;
            logoPictureBox.Location =
                new Point(
                    logoPictureBox.Location.X
                    - layoutPictureBox.Location.X,
                    logoPictureBox.Location.Y
                    - layoutPictureBox.Location.Y);

        }
    }
}
