﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class LoggingIn : Form
    {
        public LoggingIn loggingIn;

        public string loginUsername { get; set; }
        public string loginPassword { get; set; }
        public LoggingIn()
        {
            InitializeComponent();
            this.loggingIn = this;
            this.loginUsername = usernameTextBox.Text;
            this.loginPassword = passwordTextBox.Text;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnFormClosing(e);
        }

        private void backToRegister_Click(object sender, EventArgs e)
        {
            Login m = new Login();
            m.Show();
            Visible = false;
        }

        private void showPasswordLoginCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (showCheckBox.Checked)
            {
                passwordTextBox.UseSystemPasswordChar = false;
            }
            else
            {
                passwordTextBox.UseSystemPasswordChar = true;
            }
        }

        //private void usernameLoginTxt_TextChanged(object sender, EventArgs e)
        //{

        //    string username = usernameTextBox.Text;
        //    int registered = (int)userTableAdapter.LoginRegisteredUsername(username);

        //    if (registered == 1)
        //    {
        //        passwordLabel.Visible = true;
        //        passwordTextBox.Visible = true;
        //        showCheckBox.Visible = true;
        //        loginButton.Visible = true;
        //    }
        //}
        private void exitLoginBtn_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }
    }
}

        //private void loginBtn_Click(object sender, EventArgs e)
        //{
        //    string username = usernameTextBox.Text;
        //    string password = passwordTextBox.Text;

           // int registered = (int)userTableAdapter.LoginCompleteValidation(username, password);

            //if (registered == 1)
            //{

            //    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    this.loginUsername = username;
            //    this.loginPassword = password;
            //   // MenuForm dashboard = new MenuForm(login);
            //  //  dashboard.Show();
        //    //    this.Visible = false;

        //    }
        //    else
        //    {
        //        MessageBox.Show("Invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //    }
        //}
            

        
    