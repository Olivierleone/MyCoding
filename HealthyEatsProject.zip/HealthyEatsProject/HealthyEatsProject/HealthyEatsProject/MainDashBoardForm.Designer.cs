﻿namespace HealthyEatsProject
{
    partial class MainDashBoardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.communityForumButton = new System.Windows.Forms.Button();
            this.GroceryListGeneratorButton = new System.Windows.Forms.Button();
            this.recipeExplorerButton = new System.Windows.Forms.Button();
            this.personalizedMealPlanningButton = new System.Windows.Forms.Button();
            this.mainLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // communityForumButton
            // 
            this.communityForumButton.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.communityForumButton.Location = new System.Drawing.Point(462, 493);
            this.communityForumButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.communityForumButton.Name = "communityForumButton";
            this.communityForumButton.Size = new System.Drawing.Size(223, 70);
            this.communityForumButton.TabIndex = 9;
            this.communityForumButton.Text = "Community Forum";
            this.communityForumButton.UseVisualStyleBackColor = true;
            this.communityForumButton.Click += new System.EventHandler(this.CommunityForumButton_Click);
            // 
            // GroceryListGeneratorButton
            // 
            this.GroceryListGeneratorButton.AutoSize = true;
            this.GroceryListGeneratorButton.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroceryListGeneratorButton.Location = new System.Drawing.Point(462, 422);
            this.GroceryListGeneratorButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GroceryListGeneratorButton.Name = "GroceryListGeneratorButton";
            this.GroceryListGeneratorButton.Size = new System.Drawing.Size(223, 67);
            this.GroceryListGeneratorButton.TabIndex = 8;
            this.GroceryListGeneratorButton.Text = "Grocery List Generator";
            this.GroceryListGeneratorButton.UseVisualStyleBackColor = true;
            this.GroceryListGeneratorButton.Click += new System.EventHandler(this.GroceryListGeneratorButton_Click);
            // 
            // recipeExplorerButton
            // 
            this.recipeExplorerButton.AutoSize = true;
            this.recipeExplorerButton.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recipeExplorerButton.Location = new System.Drawing.Point(182, 422);
            this.recipeExplorerButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.recipeExplorerButton.Name = "recipeExplorerButton";
            this.recipeExplorerButton.Size = new System.Drawing.Size(253, 67);
            this.recipeExplorerButton.TabIndex = 7;
            this.recipeExplorerButton.Text = "Recipe Explorer";
            this.recipeExplorerButton.UseVisualStyleBackColor = true;
            this.recipeExplorerButton.Click += new System.EventHandler(this.RecipeExploreButton_Click);
            // 
            // personalizedMealPlanningButton
            // 
            this.personalizedMealPlanningButton.AutoSize = true;
            this.personalizedMealPlanningButton.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personalizedMealPlanningButton.Location = new System.Drawing.Point(182, 493);
            this.personalizedMealPlanningButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.personalizedMealPlanningButton.Name = "personalizedMealPlanningButton";
            this.personalizedMealPlanningButton.Size = new System.Drawing.Size(253, 66);
            this.personalizedMealPlanningButton.TabIndex = 6;
            this.personalizedMealPlanningButton.Text = "Personalized Meal Planning";
            this.personalizedMealPlanningButton.UseVisualStyleBackColor = true;
            this.personalizedMealPlanningButton.Click += new System.EventHandler(this.PersonalizedMealPlanningButton_Click);
            // 
            // mainLabel
            // 
            this.mainLabel.AutoSize = true;
            this.mainLabel.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainLabel.Location = new System.Drawing.Point(287, 28);
            this.mainLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mainLabel.Name = "mainLabel";
            this.mainLabel.Size = new System.Drawing.Size(309, 31);
            this.mainLabel.TabIndex = 5;
            this.mainLabel.Text = "Welcome to Healthy Eats";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.monthCalendar1);
            this.panel1.Location = new System.Drawing.Point(21, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(810, 329);
            this.panel1.TabIndex = 10;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(42, 27);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 0;
            // 
            // MainDashBoardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(862, 602);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.communityForumButton);
            this.Controls.Add(this.GroceryListGeneratorButton);
            this.Controls.Add(this.recipeExplorerButton);
            this.Controls.Add(this.personalizedMealPlanningButton);
            this.Controls.Add(this.mainLabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "MainDashBoardForm";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button communityForumButton;
        private System.Windows.Forms.Button GroceryListGeneratorButton;
        private System.Windows.Forms.Button recipeExplorerButton;
        private System.Windows.Forms.Button personalizedMealPlanningButton;
        private System.Windows.Forms.Label mainLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}

