﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class GroceryListGeneratorForm : Form
    {

        private List<GroceryItem> groceryItems = new List<GroceryItem>();

        public GroceryListGeneratorForm()
        {
            InitializeComponent();
        }

        private void UpdateRichTextBox()
        {
            outputRichTextBox.Clear();

            foreach (var item in groceryItems)
            {
                // Use formatting to align the text in columns
                string formattedItem = $"{item.ItemName,-40} {item.Amount,-10} {item.Unit}\n";
                outputRichTextBox.AppendText(formattedItem);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            string itemName = descriptionTextBox.Text;
            string amount = amountTextBox.Text;
            string unit = unitComboBox.SelectedItem as string;

            if (string.IsNullOrWhiteSpace(itemName) || string.IsNullOrWhiteSpace(amount) || string.IsNullOrWhiteSpace(unit))
            {
                MessageBox.Show("Please enter valid values for item name, amount, and unit.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            groceryItems.Add(new GroceryItem { ItemName = itemName, Amount = amount, Unit = unit });
            UpdateRichTextBox();
        }

        private void ChangeButton_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = outputRichTextBox.GetLineFromCharIndex(outputRichTextBox.SelectionStart);

            if (selectedRowIndex >= 0 && selectedRowIndex < groceryItems.Count)
            {
                string itemName = descriptionTextBox.Text;
                string amount = amountTextBox.Text;
                string unit = unitComboBox.SelectedItem as string;

                if (string.IsNullOrWhiteSpace(itemName) || string.IsNullOrWhiteSpace(amount) || string.IsNullOrWhiteSpace(unit))
                {
                    MessageBox.Show("Please enter valid values for item name, amount, and unit.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                groceryItems[selectedRowIndex].ItemName = itemName;
                groceryItems[selectedRowIndex].Amount = amount;
                groceryItems[selectedRowIndex].Unit = unit;

                UpdateRichTextBox();
            }
            else
            {
                MessageBox.Show("Please select a row to change.", "No Row Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = outputRichTextBox.GetLineFromCharIndex(outputRichTextBox.SelectionStart);

            if (selectedRowIndex >= 0 && selectedRowIndex < groceryItems.Count)
            {
                groceryItems.RemoveAt(selectedRowIndex);
                UpdateRichTextBox();
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "No Row Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            // Navigate back to the main dashboard
            MainDashBoardForm mainDashboardForm = new MainDashBoardForm();
            mainDashboardForm.Show();
            this.Close();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the entire application when the "Exit" button is clicked
            Application.Exit();
        }

        public class GroceryItem
        {
            public string ItemName { get; set; }
            public string Amount { get; set; }
            public string Unit { get; set; }
        }
    }
}