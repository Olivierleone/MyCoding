﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class MainDashBoardForm : Form
    {
        public MainDashBoardForm()
        {
            InitializeComponent();
        }
        private void RecipeExploreButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the RecipeExplorerForm
            RecipeExplorerForm recipeExplorerForm = new RecipeExplorerForm(this); // Pass 'this' as the main dashboard form reference

            // Show the RecipeExplorerForm
            recipeExplorerForm.Show();

            // Optionally, you can hide the current form if needed
            this.Hide();
        }
        private void PersonalizedMealPlanningButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the PersonalizedMealPlanningForm
            PersonalizedMealPlanningForm mealPlanningForm = new PersonalizedMealPlanningForm();

            // Show the PersonalizedMealPlanningForm
            mealPlanningForm.Show();

            // Optionally, you can hide the current form if needed
            this.Hide();
        }

        private void GroceryListGeneratorButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the GroceryListGeneratorForm
            GroceryListGeneratorForm groceryListForm = new GroceryListGeneratorForm();

            // Show the GroceryListGeneratorForm
            groceryListForm.Show();

            // Optionally, you can hide the current form if needed
            this.Hide();
        }

        private void CommunityForumButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the CommunityForumForm
            CommunityForumForm communityForumForm = new CommunityForumForm();

            // Show the CommunityForumForm
            communityForumForm.Show();

            // Optionally, you can hide the current form if needed
            this.Hide();
        }
    }
}
    

