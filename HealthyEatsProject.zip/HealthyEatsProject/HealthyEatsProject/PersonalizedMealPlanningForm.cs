﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class PersonalizedMealPlanningForm : Form
    {
        
        public PersonalizedMealPlanningForm()
        {
            InitializeComponent();
        }

        private void generateMealPlanButton_Click(object sender, EventArgs e)
        {
            string userName = nameTextBox.Text;
            int numberOfMeals = (int)mealsNumericUpDown.Value;

            // Gather selected dietary preferences
            bool isVegetarian = vegetarianCheckBox.Checked;
            bool isVegan = veganCheckBox.Checked;
            bool isGlutenFree = glutenFreeCheckBox.Checked;

            // Gather selected allergies
            List<string> allergies = new List<string>();
            if (peanutsCheckBox.Checked)
            {
                allergies.Add("peanuts");
            }
            if (shellFishTextBox.Checked)
            {
                allergies.Add("shellfish");
            }
            if (eggTextBox.Checked)
            {
                allergies.Add("egg");
            }

            List<string> mealPlan = GenerateMealPlan(numberOfMeals, isVegetarian, isVegan, isGlutenFree, allergies);

            // Display the meal plan
            resultTextBox.Text = $"Here's your personalized meal plan, {userName}:\r\n";

            for (int i = 0; i < mealPlan.Count; i++)
            {
                resultTextBox.AppendText($"Meal {i + 1}: {mealPlan[i]}\r\n");
            }


        }
      
        static Dictionary<string, string> NutritionalInformation()
        {
         Dictionary<string, string> nutritionalInfo = new Dictionary<string, string>
    {   { "Quinoa Salad with Roasted Vegetables", "Calories: 300, Protein: 10g, Carbs: 50g, Fats: 8g" },
        { "Gluten-Free Vegetarian Pizza", "Calories: 400, Protein: 15g, Carbs: 40g, Fats: 18g" },
        { "Stuffed Bell Peppers with Quinoa", "Calories: 250, Protein: 8g, Carbs: 30g, Fats: 12g" },
        { "Vegetarian Stir-Fry with Gluten-Free Soy Sauce", "Calories: 350, Protein: 12g, Carbs: 45g, Fats: 10g" },
        { "Sweet Potato and Chickpea Curry", "Calories: 320, Protein: 9g, Carbs: 55g, Fats: 7g" },
        { "Gluten-Free Pasta Primavera", "Calories: 380, Protein: 14g, Carbs: 42g, Fats: 15g" },
        { "Mushroom and Spinach Quinoa Bowl", "Calories: 310, Protein: 11g, Carbs: 38g, Fats: 11g" },
        { "Vegetarian Sushi with Gluten-Free Soy Sauce", "Calories: 280, Protein: 10g, Carbs: 50g, Fats: 6g" },
        { "Gluten-Free Spinach and Feta Stuffed Mushrooms", "Calories: 200, Protein: 7g, Carbs: 25g, Fats: 9g" },
        { "Chickpea and Vegetable Stir-Fry", "Calories: 330, Protein: 13g, Carbs: 40g, Fats: 12g" },
        { "Vegetarian Salad", "Calories: 200, Protein: 5g, Carbs: 30g, Fats: 8g" },
        { "Vegetarian Pizza", "Calories: 300, Protein: 12g, Carbs: 35g, Fats: 14g" },
        { "Stir-Fried Tofu", "Calories: 220, Protein: 10g, Carbs: 15g, Fats: 12g" },
        { "Quinoa Bowl", "Calories: 250, Protein: 9g, Carbs: 45g, Fats: 6g" },
        { "Caprese Sandwich", "Calories: 280, Protein: 8g, Carbs: 30g, Fats: 15g" },
        { "Eggplant Parmesan", "Calories: 320, Protein: 10g, Carbs: 25g, Fats: 18g" },
        { "Vegetarian Sushi", "Calories: 180, Protein: 6g, Carbs: 40g, Fats: 4g" },
        { "Mushroom Risotto", "Calories: 350, Protein: 8g, Carbs: 60g, Fats: 10g" },
        { "Greek Salad", "Calories: 220, Protein: 7g, Carbs: 15g, Fats: 16g" },
        { "Sweet Potato and Black Bean Burrito", "Calories: 280, Protein: 12g, Carbs: 40g, Fats: 9g" },
       
{ "Vegan Wrap", "Calories: 300, Protein: 12g, Carbs: 40g, Fats: 8g" },
{ "Chickpea Curry", "Calories: 320, Protein: 10g, Carbs: 50g, Fats: 7g" },
{ "Roasted Vegetable Pasta", "Calories: 350, Protein: 8g, Carbs: 60g, Fats: 12g" },
{ "Vegan Burrito Bowl", "Calories: 280, Protein: 15g, Carbs: 45g, Fats: 10g" },
{ "Cashew Alfredo with Broccoli", "Calories: 380, Protein: 14g, Carbs: 30g, Fats: 18g" },
{ "Quinoa and Black Bean Stuffed Peppers", "Calories: 300, Protein: 12g, Carbs: 40g, Fats: 8g" },
{ "Vegan Pad Thai", "Calories: 320, Protein: 10g, Carbs: 50g, Fats: 7g" },
{ "Coconut Lentil Curry", "Calories: 350, Protein: 8g, Carbs: 60g, Fats: 12g" },
{ "Vegan Nachos", "Calories: 280, Protein: 15g, Carbs: 45g, Fats: 10g" },
{ "Lentil Loaf", "Calories: 380, Protein: 14g, Carbs: 30g, Fats: 18g" },


{ "Grilled Chicken Salad", "Calories: 320, Protein: 30g, Carbs: 15g, Fats: 18g" },
{ "Salmon with Lemon Dill Sauce", "Calories: 350, Protein: 25g, Carbs: 20g, Fats: 22g" },
{ "Quinoa Salad with Vegetables", "Calories: 300, Protein: 10g, Carbs: 50g, Fats: 8g" },
{ "Grilled Shrimp Skewers", "Calories: 280, Protein: 20g, Carbs: 25g, Fats: 15g" },
{ "Chicken and Vegetable Stir-Fry", "Calories: 320, Protein: 22g, Carbs: 30g, Fats: 12g" },
{ "Stuffed Bell Peppers with Ground Turkey", "Calories: 300, Protein: 18g, Carbs: 35g, Fats: 14g" },
{ "Baked Lemon Herb Cod", "Calories: 340, Protein: 22g, Carbs: 25g, Fats: 18g" },
{ "Gluten-Free Pasta with Pesto", "Calories: 360, Protein: 14g, Carbs: 45g, Fats: 15g" },
{ "Spinach and Feta Stuffed Chicken", "Calories: 310, Protein: 25g, Carbs: 20g, Fats: 12g" },
{ "Grilled Portobello Mushrooms", "Calories: 280, Protein: 12g, Carbs: 30g, Fats: 14g" },



        // Additional meals for other categories
        // ... (Add nutritional information for other meals)
    };

            return nutritionalInfo;
        }

        private void DisplayNutritionalInformation(string meal)
        {
            Dictionary<string, string> nutritionalInfo = NutritionalInformation();

            if (nutritionalInfo.ContainsKey(meal))
            {
                MessageBox.Show(nutritionalInfo[meal], "Nutritional Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Nutritional information not available for this meal.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void nutritionalInfoButton_Click(object sender, EventArgs e)
        {
            string selectedMeal = resultTextBox.SelectedText.Trim();
            if (!string.IsNullOrEmpty(selectedMeal))
            {
                DisplayNutritionalInformation(selectedMeal);
            }
            else
            {
                MessageBox.Show("Please select a meal from the generated plan.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }




        private List<string> GenerateMealPlan(int numberOfMeals, bool isVegetarian, bool isVegan, bool isGlutenFree, List<string> allergies)
        {
            List<string> mealPlan = new List<string>();

            // Customize the meal plan based on selected options
            if (isVegetarian && !isVegan && isGlutenFree)
            {
                mealPlan.AddRange(GenerateVegetarianGlutenFreeMealPlan(numberOfMeals, allergies));
            }
            else if (isVegetarian && !isVegan && !isGlutenFree)
            {
                mealPlan.AddRange(GenerateVegetarianMealPlan(numberOfMeals, allergies));
            }
            else if (!isVegetarian && isVegan && isGlutenFree)
            {
                mealPlan.AddRange(GenerateVeganGlutenFreeMealPlan(numberOfMeals, allergies));
            }
            else if (!isVegetarian && isVegan && !isGlutenFree)
            {
                mealPlan.AddRange(GenerateVeganMealPlan(numberOfMeals, allergies));
            }
            else if (!isVegetarian && !isVegan && isGlutenFree)
            {
                mealPlan.AddRange(GenerateGlutenFreeMealPlan(numberOfMeals, allergies));
            }
            else
            {
                mealPlan.AddRange(GenerateGeneralMealPlan(numberOfMeals, allergies));
            }

            return mealPlan;
        }

        static List<string> GenerateVegetarianGlutenFreeMealPlan(int numberOfMeals, List<string> allergies)
        {
            // Customize the vegetarian and gluten-free meal plan
            List<string> vegetarianGlutenFreeMeals = new List<string>
            {
                "Quinoa Salad with Roasted Vegetables",
                "Gluten-Free Vegetarian Pizza",
                "Stuffed Bell Peppers with Quinoa",
                "Vegetarian Stir-Fry with Gluten-Free Soy Sauce",
                "Sweet Potato and Chickpea Curry",
                "Gluten-Free Pasta Primavera",
                "Mushroom and Spinach Quinoa Bowl",
                "Vegetarian Sushi with Gluten-Free Soy Sauce",
                "Gluten-Free Spinach and Feta Stuffed Mushrooms",
                "Chickpea and Vegetable Stir-Fry"
            };

            return GenerateDistinctMealPlanOptions(vegetarianGlutenFreeMeals, numberOfMeals, allergies);
        }

        static List<string> GenerateDistinctMealPlanOptions(List<string> mealOptions, int numberOfMeals, List<string> allergies)
        {
            // Ensure each meal in the plan is unique and does not contain allergens
            if (numberOfMeals > mealOptions.Count)
            {
                throw new ArgumentException("Number of meals requested exceeds available meal options.");
            }

            List<string> distinctMealPlan = new List<string>();
            List<string> availableOptions = new List<string>(mealOptions);

            Random random = new Random();

            for (int i = 0; i < numberOfMeals; i++)
            {
                // Select a random meal option that does not contain allergens
                int randomIndex = random.Next(availableOptions.Count);
                string selectedMeal = availableOptions[randomIndex];

                // Check for allergens
                bool containsAllergen = allergies.Any(allergy => selectedMeal.ToLower().Contains(allergy));
                if (!containsAllergen)
                {
                    distinctMealPlan.Add(selectedMeal);
                    availableOptions.RemoveAt(randomIndex);
                }
                else
                {
                    // If the selected meal contains allergens, try again with another option
                    i--;
                }
            }

            return distinctMealPlan;
        }

        

        static List<string> GenerateVegetarianMealPlan(int numberOfMeals, List<string> allergies)
        {
            // Customize the vegetarian meal plan
            List<string> vegetarianMeals = new List<string>
            {
                "Vegetarian Salad",
                "Vegetarian Pizza",
                "Stir-Fried Tofu",
                "Quinoa Bowl",
                "Caprese Sandwich",
                "Eggplant Parmesan",
                "Vegetarian Sushi",
                "Mushroom Risotto",
                "Greek Salad",
                "Sweet Potato and Black Bean Burrito"
            };

            return GenerateDistinctMealPlanOptions(vegetarianMeals, numberOfMeals, allergies);
        }

        // ... (Other meal plan generation functions remain unchanged)

        static List<string> GenerateVeganMealPlan(int numberOfMeals, List<string> allergies)
        {
            // Customize the vegan meal plan
            List<string> veganMeals = new List<string>
            {
                "Vegan Wrap",
                "Chickpea Curry",
                "Roasted Vegetable Pasta",
                "Vegan Burrito Bowl",
                "Cashew Alfredo with Broccoli",
                "Quinoa and Black Bean Stuffed Peppers",
                "Vegan Pad Thai",
                "Coconut Lentil Curry",
                "Vegan Nachos",
                "Lentil Loaf"
            };

            return GenerateDistinctMealPlanOptions(veganMeals, numberOfMeals, allergies);
        }

        // ... (Other meal plan generation functions remain unchanged)

        static List<string> GenerateGlutenFreeMealPlan(int numberOfMeals, List<string> allergies)
        {
            // Customize the gluten-free meal plan
            List<string> glutenFreeMeals = new List<string>
            {
                "Grilled Chicken Salad",
                "Salmon with Lemon Dill Sauce",
                "Quinoa Salad with Vegetables",
                "Grilled Shrimp Skewers",
                "Chicken and Vegetable Stir-Fry",
                "Stuffed Bell Peppers with Ground Turkey",
                "Baked Lemon Herb Cod",
                "Gluten-Free Pasta with Pesto",
                "Spinach and Feta Stuffed Chicken",
                "Grilled Portobello Mushrooms"
            };

            return GenerateDistinctMealPlanOptions(glutenFreeMeals, numberOfMeals, allergies);
        }

        // ... (Other meal plan generation functions remain unchanged)

        static List<string> GenerateVeganGlutenFreeMealPlan(int numberOfMeals, List<string> allergies)
        {
            // Customize the vegan and gluten-free meal plan
            List<string> veganGlutenFreeMeals = new List<string>
            {
                "Quinoa Salad with Avocado",
                "Vegan Gluten-Free Pizza",
                "Stuffed Bell Peppers with Quinoa and Black Beans",
                "Vegan Stir-Fry with Tofu",
                "Sweet Potato and Chickpea Curry",
                "Gluten-Free Vegan Pasta Primavera",
                "Mushroom and Spinach Quinoa Bowl",
                "Vegan Sushi",
                "Gluten-Free Vegan Stuffed Mushrooms",
                "Chickpea and Vegetable Stir-Fry"
            };

            return GenerateDistinctMealPlanOptions(veganGlutenFreeMeals, numberOfMeals, allergies);
        }

        // ... (Other meal plan generation functions remain unchanged)

        static List<string> GenerateGeneralMealPlan(int numberOfMeals, List<string> allergies)
        {
            // Customize the general meal plan
            List<string> generalMeals = new List<string>
            {
                "Chicken Caesar Salad",
                "Margherita Pizza",
                "Beef Stir-Fry",
                "Spaghetti Bolognese",
                "BBQ Chicken Sandwich",
                "Grilled Salmon with Asparagus",
                "Vegetable Lasagna",
                "Shrimp Scampi",
                "Turkey and Quinoa Stuffed Peppers",
                "Teriyaki Beef Bowl"
            };

            return GenerateDistinctMealPlanOptions(generalMeals, numberOfMeals, allergies);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the application when the "Exit" button is clicked
            Application.Exit();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            // Navigate back to the main dashboard
            MainDashBoardForm mainDashboardForm = new MainDashBoardForm();
            mainDashboardForm.Show();
            this.Close();
        }

    }
}