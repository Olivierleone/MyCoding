﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class CommunityForumForm : Form
    {

        private List<string> posts; // List to store forum posts
        private Dictionary<string, Color> usernameColors; // Dictionary to store username-color associations

        public CommunityForumForm()
        {
            InitializeComponent();
            posts = new List<string>();
            usernameColors = new Dictionary<string, Color>();
            UpdatePostsListBox(); // Update the posts list box when the form is loaded
        }

        private void UpdatePostsListBox()
        {
            // Clear and update the posts list box with the latest posts
            postsListBox.Items.Clear();
            postsListBox.Items.AddRange(posts.ToArray());
        }

        private Color GetRandomColor()
        {
            // Generate a random color
            Random random = new Random();
            return Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
        }

        private void submitPostButton_Click(object sender, EventArgs e)
        {
            // Get the new post text from the input textbox
            string newPost = postTextBox.Text;

            // Get the username from the input textbox
            string username = usernameTextBox.Text;

            if (!string.IsNullOrWhiteSpace(newPost) && !string.IsNullOrWhiteSpace(username))
            {
                // Create a formatted post with username and content
                string formattedPost = $"{username}: {newPost}";

                // Add the new post to the list
                posts.Add(formattedPost);

                // Update the posts list box
                UpdatePostsListBox();

                // Clear the input textboxes after submitting the post
                postTextBox.Clear();
                usernameTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter both a valid username and post before submitting.", "Invalid Post", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            // Go back to the main dashboard form and close the community forum form
            MainDashBoardForm mainDashboardForm = new MainDashBoardForm();
            mainDashboardForm.Show();
            this.Close();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the entire application when the "Exit" button is clicked
            Application.Exit();
        }

    }
}


    

