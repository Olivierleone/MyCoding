﻿namespace HealthyEatsProject
{
    partial class CommunityForumForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CommunityForumForm));
            this.communityForumLabel = new System.Windows.Forms.Label();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.postTextBox = new System.Windows.Forms.TextBox();
            this.postButton = new System.Windows.Forms.Button();
            this.postsListBox = new System.Windows.Forms.ListBox();
            this.backButton = new System.Windows.Forms.Button();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.timeUserControl1 = new HealthyEatsProject.TimeUserControl();
            this.dateUserControl1 = new HealthyEatsProject.DateUserControl();
            this.SuspendLayout();
            // 
            // communityForumLabel
            // 
            this.communityForumLabel.AutoSize = true;
            this.communityForumLabel.BackColor = System.Drawing.Color.Honeydew;
            this.communityForumLabel.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.communityForumLabel.ForeColor = System.Drawing.Color.Green;
            this.communityForumLabel.Location = new System.Drawing.Point(173, 63);
            this.communityForumLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.communityForumLabel.Name = "communityForumLabel";
            this.communityForumLabel.Size = new System.Drawing.Size(257, 37);
            this.communityForumLabel.TabIndex = 0;
            this.communityForumLabel.Text = "Community Forum";
            // 
            // instructionLabel
            // 
            this.instructionLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLabel.ForeColor = System.Drawing.Color.Honeydew;
            this.instructionLabel.Location = new System.Drawing.Point(11, 123);
            this.instructionLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(455, 53);
            this.instructionLabel.TabIndex = 1;
            this.instructionLabel.Text = "Welcome to the Community Forum!  \r\nShare your thoughts, recipes, or health tips w" +
    "ith others.";
            // 
            // postTextBox
            // 
            this.postTextBox.BackColor = System.Drawing.Color.Honeydew;
            this.postTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postTextBox.Location = new System.Drawing.Point(112, 240);
            this.postTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.postTextBox.Multiline = true;
            this.postTextBox.Name = "postTextBox";
            this.postTextBox.Size = new System.Drawing.Size(357, 75);
            this.postTextBox.TabIndex = 2;
            // 
            // postButton
            // 
            this.postButton.AutoSize = true;
            this.postButton.BackColor = System.Drawing.Color.DarkOrange;
            this.postButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.postButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.postButton.Location = new System.Drawing.Point(240, 319);
            this.postButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.postButton.Name = "postButton";
            this.postButton.Size = new System.Drawing.Size(97, 33);
            this.postButton.TabIndex = 4;
            this.postButton.Text = "Post";
            this.postButton.UseVisualStyleBackColor = false;
            this.postButton.Click += new System.EventHandler(this.submitPostButton_Click);
            // 
            // postsListBox
            // 
            this.postsListBox.BackColor = System.Drawing.Color.Honeydew;
            this.postsListBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postsListBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.postsListBox.FormattingEnabled = true;
            this.postsListBox.ItemHeight = 21;
            this.postsListBox.Location = new System.Drawing.Point(15, 376);
            this.postsListBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.postsListBox.Name = "postsListBox";
            this.postsListBox.Size = new System.Drawing.Size(451, 130);
            this.postsListBox.TabIndex = 6;
            // 
            // backButton
            // 
            this.backButton.AutoSize = true;
            this.backButton.BackColor = System.Drawing.Color.DarkOrange;
            this.backButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.backButton.Location = new System.Drawing.Point(134, 548);
            this.backButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(99, 37);
            this.backButton.TabIndex = 7;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // usernameLabel
            // 
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameLabel.ForeColor = System.Drawing.Color.Honeydew;
            this.usernameLabel.Location = new System.Drawing.Point(14, 202);
            this.usernameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(83, 21);
            this.usernameLabel.TabIndex = 8;
            this.usernameLabel.Text = "Username";
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.BackColor = System.Drawing.Color.Honeydew;
            this.usernameTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameTextBox.Location = new System.Drawing.Point(112, 197);
            this.usernameTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(357, 29);
            this.usernameTextBox.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.DarkOrange;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(253, 548);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 37);
            this.button1.TabIndex = 10;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Honeydew;
            this.label1.Location = new System.Drawing.Point(14, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 21);
            this.label1.TabIndex = 11;
            this.label1.Text = "Comments";
            // 
            // timeUserControl1
            // 
            this.timeUserControl1.Location = new System.Drawing.Point(294, 5);
            this.timeUserControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.timeUserControl1.Name = "timeUserControl1";
            this.timeUserControl1.Size = new System.Drawing.Size(196, 54);
            this.timeUserControl1.TabIndex = 13;
            // 
            // dateUserControl1
            // 
            this.dateUserControl1.AutoSize = true;
            this.dateUserControl1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateUserControl1.Location = new System.Drawing.Point(0, 5);
            this.dateUserControl1.Margin = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.dateUserControl1.Name = "dateUserControl1";
            this.dateUserControl1.Size = new System.Drawing.Size(337, 41);
            this.dateUserControl1.TabIndex = 14;
            // 
            // CommunityForumForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(502, 626);
            this.Controls.Add(this.dateUserControl1);
            this.Controls.Add(this.timeUserControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.usernameTextBox);
            this.Controls.Add(this.usernameLabel);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.postsListBox);
            this.Controls.Add(this.postButton);
            this.Controls.Add(this.postTextBox);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.communityForumLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CommunityForumForm";
            this.Text = "Community Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label communityForumLabel;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.TextBox postTextBox;
        private System.Windows.Forms.Button postButton;
        private System.Windows.Forms.ListBox postsListBox;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Label usernameLabel;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private TimeUserControl timeUserControl1;
        private DateUserControl dateUserControl1;
    }
}