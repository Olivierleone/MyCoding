﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace HealthyEatsProject
{
    public partial class SignUp : Form
    {
        private readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Olivier\Downloads\HealthyEatsProject\HealthyEatsProject-20231205T082621Z-001_2\HealthyEatsProject-20231205T082621Z-001\HealthyEatsProject\HealthyEatsProject\UserDatabase.mdf;Integrated Security=True;Connect Timeout=30";
        public SignUp()
        {
            InitializeComponent();
        }

        private void showPasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            passwordTextBox.UseSystemPasswordChar = showPasswordCheckBox.Checked;
            confirmPasswordTextBox.UseSystemPasswordChar = showPasswordCheckBox.Checked;
        }

        private void AlreadyLabel_Click(object sender, EventArgs e)
        {
            LogIn loginForm = new LogIn();
            loginForm.Show();
            this.Hide();
        }

        private void signUpButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;
            string confirmPassword = confirmPasswordTextBox.Text;

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidPassword(password))
            {
                MessageBox.Show("Password must have one capital, one special character and be at least 8 characters long.", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (UserExists(username))
            {
                MessageBox.Show("Username already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            CreateUser(username, password);
            MessageBox.Show($"Signup successful for user: {username}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            LogIn loginForm = new LogIn();
            loginForm.Show();
            this.Hide();
        }

        private bool IsValidPassword(string password)
        {
            return password.Length >= 8 && password.Any(char.IsUpper) && password.Any(char.IsPunctuation);
        }

        private bool UserExists(string username)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(1) FROM [User] WHERE UserName = @username", conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    int userCount = (int)cmd.ExecuteScalar();
                    return userCount > 0;
                }
            }
        }

        private void CreateUser(string username, string password)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("INSERT INTO [User] (UserName, Password) VALUES (@username, @password)", conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password); // Consider using password hashing for security
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

