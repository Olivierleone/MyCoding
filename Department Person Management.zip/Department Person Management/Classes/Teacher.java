/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources;

import java.util.Objects;

/**
 *
 * @author Olivier
 */
public class Teacher extends Person implements IPayRoll {

    protected String speciality;
    protected String degree;
    protected int YearsOfExperience;
    protected int departmentIdTeacher;

    public Teacher() {

        this.speciality = "";
        this.degree = "";
        this.YearsOfExperience = 0;
        this.departmentIdTeacher = 0;

    }

    public Teacher(String speciality, String degree, int YearsOfExperience, int departmentIdTeacher) {
        super();
        this.speciality = speciality;
        this.degree = degree;
        this.YearsOfExperience = YearsOfExperience;
        this.departmentIdTeacher = departmentIdTeacher;

    }

    public Teacher(Teacher obj) {
        speciality = obj.speciality;
        degree = obj.degree;
        YearsOfExperience = obj.YearsOfExperience;
        departmentIdTeacher = obj.departmentIdTeacher;
    }

    @Override
    public double computePayRoll() {
        double salary = 0.0;
        if (degree.equalsIgnoreCase("PhD")) {
            salary = 32 * 122 * 2 * 0.85;
        } else if (degree.equalsIgnoreCase("Master")) {
            salary = 32 * 82 * 2 * 0.85;
        } else if (degree.equalsIgnoreCase("Bachelor")) {
            salary = 32 * 42 * 2 * 0.85;

        }

        return salary;
    }

    @Override
    public String toString() {
        return "Teacher:" + "speciality: " + speciality
                + "degree: " + degree
                + "YearsOfExperience: " + YearsOfExperience
                + "departmentId: " + departmentIdTeacher;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.speciality);
        hash = 59 * hash + Objects.hashCode(this.degree);
        hash = 59 * hash + this.YearsOfExperience;
        hash = 59 * hash + this.departmentIdTeacher;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Teacher other = (Teacher) obj;
        if (this.YearsOfExperience != other.YearsOfExperience) {
            return false;
        }
        if (this.departmentIdTeacher != other.departmentIdTeacher) {
            return false;
        }
        if (!Objects.equals(this.speciality, other.speciality)) {
            return false;
        }
        if (!Objects.equals(this.degree, other.degree)) {
            return false;
        }
        return true;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getYearsOfExperience() {
        return YearsOfExperience;
    }

    public void setYearsOfExperience(int YearsOfExperience) {
        this.YearsOfExperience = YearsOfExperience;
    }

    public int getDepartmentIdTeacher() {
        return departmentIdTeacher;
    }

    public void setDepartmentIdTeacher(int departmentIdTeacher) {
        this.departmentIdTeacher = departmentIdTeacher;

    }

}
