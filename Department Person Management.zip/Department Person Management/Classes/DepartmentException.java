/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources;

/**
 *
 * @author Olivier
 */
public class DepartmentException extends Exception {

    public DepartmentException(String message) {
        super(message);
    }

    public static class TeacherAlreadyAddedException extends DepartmentException {

        public TeacherAlreadyAddedException(String message) {
            super(message);
        }
    }

    public static class StaffAlreadyAddedException extends DepartmentException {

        public StaffAlreadyAddedException(String message) {
            super(message);
        }
    }

    public static class InvalidDepartmentIdException extends DepartmentException {

        public InvalidDepartmentIdException(String message) {
            super(message);
        }
    }

    public static class InvalidDeanException extends DepartmentException {

        public InvalidDeanException(String message) {
            super(message);
        }
    }
}
