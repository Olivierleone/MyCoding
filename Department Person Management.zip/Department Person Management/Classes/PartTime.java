/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources;

/**
 *
 * @author Olivier
 */
public class PartTime extends Teacher {

    private double hoursWorkedPart;

    public PartTime() {
        this.hoursWorkedPart = 0.0;
    }

    public PartTime(double hoursWorkedPart, String speciality, String degree, int YearsOfExperience, int departmentIdTeacher) {
        super(speciality, degree, YearsOfExperience, departmentIdTeacher);
        this.hoursWorkedPart = hoursWorkedPart;
    }

    public PartTime(PartTime obj) {
        hoursWorkedPart = obj.hoursWorkedPart;
    }

    public void checkWorkload() {
        if (hoursWorkedPart < 35) {
            System.out.println("Part-time teacher has worked less than 35 hours.");
        } else {
            System.out.println("Part-time teacher has worked 35 hours or more.");
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + (int) (Double.doubleToLongBits(this.hoursWorkedPart) ^ (Double.doubleToLongBits(this.hoursWorkedPart) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PartTime other = (PartTime) obj;
        if (Double.doubleToLongBits(this.hoursWorkedPart) != Double.doubleToLongBits(other.hoursWorkedPart)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "PartTime: " + "Hours Worked: " + hoursWorkedPart;
    }

    public double getHoursWorkedPart() {
        return hoursWorkedPart;
    }

    public void setHoursWorkedPart(double hoursWorkedPart) {
        this.hoursWorkedPart = hoursWorkedPart;
    }

}
