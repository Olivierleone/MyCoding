/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources;

/**
 *
 * @author Olivier
 */
public class FullTime extends Teacher {

    private int hoursWorkedFull;

    public FullTime() {
        super();
        this.hoursWorkedFull = 0;
    }

    public FullTime(int hoursWorkedFull, String speciality, String degree, int YearsOfExperience, int departmentIdTeacher) {
        super(speciality, degree, YearsOfExperience, departmentIdTeacher);
        this.hoursWorkedFull = hoursWorkedFull;
    }

    

 

    public FullTime(int hoursWorked, Teacher obj) {
        super(obj);
        this.hoursWorkedFull = hoursWorked;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 71 * hash + this.hoursWorkedFull;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FullTime other = (FullTime) obj;
        if (this.hoursWorkedFull != other.hoursWorkedFull) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "FullTime: " + "Hours Worked: " + hoursWorkedFull;
    }

    public int getHoursWorkedFull() {
        return hoursWorkedFull;
    }

    public void setHoursWorkedFull(int hoursWorkedFull) {
        this.hoursWorkedFull = hoursWorkedFull;
    }

    public void checkWorkload() {
        if (hoursWorkedFull > 40) {
            System.out.println("Full-time teacher has worked more than 40 hours.");
        } else {
            System.out.println("Full-time teacher has worked 40 hours or less.");
        }
    }
}
