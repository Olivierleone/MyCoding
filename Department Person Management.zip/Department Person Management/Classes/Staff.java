/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources;

import java.util.Objects;

/**
 *
 * @author Olivier
 */
public class Staff extends Person implements IPayRoll {

    private String duty;
    private double workload;
    private int departmentIdStaff;

    public Staff() {

        this.duty = "";
        this.workload = 0.0;
        this.departmentIdStaff = 0;

    }

    public Staff(String duty, double workload, int departmentIdStaff, String firstname, String lastName, String email, String phone, String address) {
        super(firstname, lastName, email, phone, address);
        this.duty = duty;
        this.workload = workload;
        this.departmentIdStaff = departmentIdStaff;
    }

    public Staff(Staff obj) {
        duty = obj.duty;
        workload = obj.workload;
        departmentIdStaff = obj.departmentIdStaff;

    }

    @Override
    public double computePayRoll() {
        return (workload <= 40) ? (workload * 32 * 2) * 0.75 : (40 * 32 * 2) * 0.75;
    }

    @Override
    public String toString() {
        return "Staff:" + "duty:" + duty
                + "workload: " + workload
                + "DepartmentIdStaff: " + departmentIdStaff;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.duty);
        hash = 17 * hash + (int) (Double.doubleToLongBits(this.workload) ^ (Double.doubleToLongBits(this.workload) >>> 32));
        hash = 17 * hash + this.departmentIdStaff;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Staff other = (Staff) obj;
        if (Double.doubleToLongBits(this.workload) != Double.doubleToLongBits(other.workload)) {
            return false;
        }
        if (this.departmentIdStaff != other.departmentIdStaff) {
            return false;
        }
        if (!Objects.equals(this.duty, other.duty)) {
            return false;
        }
        return true;
    }

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public double getWorkload() {
        return workload;
    }

    public void setWorkload(double workload) {
        this.workload = workload;
    }

    public int getDepartmentIdStaff() {
        return departmentIdStaff;
    }

    public void setDepartmentIdStaff(int departmentIdStaff) {
        this.departmentIdStaff = departmentIdStaff;
    }

}
