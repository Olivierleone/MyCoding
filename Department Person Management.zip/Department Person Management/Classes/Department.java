/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources;

import humanresources.DepartmentException.InvalidDeanException;
import humanresources.DepartmentException.InvalidDepartmentIdException;
import humanresources.DepartmentException.StaffAlreadyAddedException;
import humanresources.DepartmentException.TeacherAlreadyAddedException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Olivier
 */
public class Department {

    private int id;
    private String name;
    private List<Teacher> teachers;
    private List<Staff> staffs;
    private Teacher dean;

    public Department() {

        this.id = 0;
        this.name = "";
        this.teachers = new ArrayList<>();
        this.staffs = new ArrayList<>(staffs);
        this.dean = null;

    }

    public Department(int id, String name, List<Teacher> teachers, List<Staff> staff, Teacher dean) throws InvalidDeanException {
        this.id = id;
        this.name = name;
        this.teachers = teachers;
        this.staffs = staff;
        if (dean.departmentIdTeacher != this.id) {
            throw new InvalidDeanException("This specified teacher is not a member of this department");
        }
        this.dean = dean;
    }

    public Department(Department obj) {

        id = obj.id;
        name = obj.name;
        teachers = obj.teachers;
        staffs = obj.staffs;
        dean = obj.dean;

    }

    public void addTeacher(Teacher teacher) throws TeacherAlreadyAddedException, InvalidDepartmentIdException {

        if (teachers.contains(teacher)) {
            throw new TeacherAlreadyAddedException("Teacher already added to department");
        } else if (teacher.departmentIdTeacher != this.id) {
            throw new InvalidDepartmentIdException("Teacher cannot be added to an inexistent department.");
        }
        teachers.add(teacher);
    }

    public void addStaff(Staff staff) throws StaffAlreadyAddedException, InvalidDepartmentIdException {
        {
            if (staffs.contains(staff)) {
                throw new StaffAlreadyAddedException("Staff member already added to department");
            } else if (staff.getDepartmentIdStaff() != this.id) {
                throw new InvalidDepartmentIdException("Staff cannot be added to an inexistent department.");
            }
            staffs.add(staff);
        }

    }

    public void removeTeacher(Teacher teacher) {
        teachers.remove(teacher);
    }

    public Teacher getTeacherById(int idGet) {

        for (Teacher teacher : teachers) {
            if (teacher.departmentIdTeacher == idGet) {
                return teacher;
            }
        }

        return null;
    }

    public Staff getStaffById(int idGet) {

        for (Staff staff : staffs) {
            if (staff.getDepartmentIdStaff() == idGet) {
                return staff;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "Department:" + "id:" + id
                + "name: " + name
                + "teachers: " + teachers
                + "staff: " + staffs
                + "dean: " + dean;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + this.id;
        hash = 37 * hash + Objects.hashCode(this.name);
        hash = 37 * hash + Objects.hashCode(this.teachers);
        hash = 37 * hash + Objects.hashCode(this.staffs);
        hash = 37 * hash + Objects.hashCode(this.dean);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Department other = (Department) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.teachers, other.teachers)) {
            return false;
        }
        if (!Objects.equals(this.staffs, other.staffs)) {
            return false;
        }
        if (!Objects.equals(this.dean, other.dean)) {
            return false;
        }
        return true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public List<Staff> getStaffs() {
        return staffs;
    }

    public void setStaffs(List<Staff> staff) {
        this.staffs = staff;
    }

    public Teacher getDean() {
        return dean;
    }

    public void setDean(Teacher dean) throws InvalidDeanException {
        if (dean.getDepartmentIdTeacher() != this.id) {
            throw new InvalidDeanException("The specified teacher is not a member of this department");
        }

        this.dean = dean;
    }

}
